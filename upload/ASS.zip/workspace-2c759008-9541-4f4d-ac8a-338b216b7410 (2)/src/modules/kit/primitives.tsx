'use client'

import * as React from 'react'
import { useFactory } from '@/factory/store'
import { cn } from '@/lib/utils'

/**
 * ModuleTag — factory inspection aid. Renders the module id(s) + the tier at
 * which the module enters the ladder, so the composed templates can be
 * audited visually. Hidden unless "Show module labels" is enabled.
 */
export function ModuleTag({ ids, className }: { ids: string[]; className?: string }) {
  const show = useFactory((s) => s.showLabels)
  if (!show) return null
  return (
    <div
      aria-hidden="true"
      className={cn(
        'pointer-events-none absolute left-2 top-2 z-30 flex max-w-[calc(100%-1rem)] flex-wrap gap-1',
        className,
      )}
    >
      {ids.map((id) => {
        const [name, tier] = id.split('@')
        return (
          <span
            key={id}
            className="rounded-sm border border-dashed border-amber-600/60 bg-amber-500/10 px-1.5 py-0.5 font-mono text-[9px] font-medium uppercase tracking-wider text-amber-700 backdrop-blur-sm dark:border-amber-400/50 dark:text-amber-300"
          >
            {name}
            {tier ? <span className="opacity-70"> ·T{tier}</span> : null}
          </span>
        )
      })}
    </div>
  )
}

/**
 * Section — consistent section shell (eyebrow / title / description / CTA)
 * shared by every composed template.
 */
export function Section({
  id,
  eyebrow,
  title,
  description,
  children,
  className,
  containerClassName,
  tone = 'default',
}: {
  id?: string
  eyebrow?: string
  title?: string
  description?: string
  children?: React.ReactNode
  className?: string
  containerClassName?: string
  tone?: 'default' | 'muted' | 'dark'
}) {
  return (
    <section
      id={id}
      className={cn(
        'relative scroll-mt-28 py-14 @min-[768px]:py-20',
        tone === 'muted' && 'bg-muted/40',
        tone === 'dark' && 'bg-zinc-950 text-zinc-100',
        className,
      )}
    >
      <div className={cn('mx-auto w-full max-w-6xl px-4 @min-[640px]:px-6', containerClassName)}>
        {(eyebrow || title || description) && (
          <header className={cn('mb-8 max-w-2xl @min-[768px]:mb-12', !description && 'mb-8')}>
            {eyebrow && (
              <p
                className={cn(
                  'mb-2 text-xs font-semibold uppercase tracking-[0.18em]',
                  tone === 'dark' ? 'text-amber-400' : 'text-primary',
                )}
              >
                {eyebrow}
              </p>
            )}
            {title && (
              <h2
                className={cn(
                  'text-2xl font-bold tracking-tight @min-[640px]:text-3xl @min-[768px]:text-4xl',
                  tone === 'dark' ? 'text-zinc-50' : 'text-foreground',
                )}
              >
                {title}
              </h2>
            )}
            {description && (
              <p
                className={cn(
                  'mt-3 text-sm leading-relaxed @min-[640px]:text-base',
                  tone === 'dark' ? 'text-zinc-400' : 'text-muted-foreground',
                )}
              >
                {description}
              </p>
            )}
          </header>
        )}
        {children}
      </div>
    </section>
  )
}

/** DemoContentBadge — mandatory marker for all fictional proof. */
export function DemoContentBadge({ label = 'Demo content' }: { label?: string }) {
  return (
    <span
      title="All figures and quotes on this template are fictional demo content"
      className="inline-flex items-center gap-1 rounded-full border border-dashed border-muted-foreground/40 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground"
    >
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M12 3l9 16H3z" />
        <path d="M12 10v4M12 17h.01" />
      </svg>
      {label}
    </span>
  )
}
