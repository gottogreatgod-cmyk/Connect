import { GrowthOS } from "@/shell/growth-os";

export default function Home() {
  return <GrowthOS />;
}
