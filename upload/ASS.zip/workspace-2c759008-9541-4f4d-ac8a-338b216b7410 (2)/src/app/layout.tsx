import type { Metadata, Viewport } from "next";
import {
  Archivo,
  Archivo_Black,
  Bricolage_Grotesque,
  Cormorant_Garamond,
  DM_Sans,
  DM_Serif_Display,
  Fraunces,
  IBM_Plex_Sans,
  Instrument_Serif,
  Inter,
  JetBrains_Mono,
  Manrope,
  Newsreader,
  Outfit,
  Playfair_Display,
  Space_Grotesk,
  Syne,
} from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

/* ── the type cabinet ─────────────────────────────────────────────
   Every template's voice and every edition's display resolve through
   these --gf-* variables (see lib/engine/genome.ts + lib/editions.ts).
   Fallbacks keep each stack honest even before a face loads. */

const fraunces = Fraunces({ subsets: ["latin"], variable: "--gf-fraunces", style: ["normal", "italic"] });
const inter = Inter({ subsets: ["latin"], variable: "--gf-inter" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--gf-jetbrains-mono" });
const cormorant = Cormorant_Garamond({ subsets: ["latin"], variable: "--gf-cormorant", weight: ["400", "500", "600"], style: ["normal", "italic"], preload: false });
const plex = IBM_Plex_Sans({ subsets: ["latin"], variable: "--gf-plex-sans", weight: ["400", "500", "600"], preload: false });
const space = Space_Grotesk({ subsets: ["latin"], variable: "--gf-space-grotesk", preload: false });
const dmSans = DM_Sans({ subsets: ["latin"], variable: "--gf-dm-sans", preload: false });
const syne = Syne({ subsets: ["latin"], variable: "--gf-syne", preload: false });
const manrope = Manrope({ subsets: ["latin"], variable: "--gf-manrope", preload: false });
const instrument = Instrument_Serif({ subsets: ["latin"], variable: "--gf-instrument-serif", weight: "400", style: ["normal", "italic"], preload: false });
const playfair = Playfair_Display({ subsets: ["latin"], variable: "--gf-playfair", style: ["normal", "italic"], preload: false });
const newsreader = Newsreader({ subsets: ["latin"], variable: "--gf-newsreader", style: ["normal", "italic"], preload: false });
const dmSerif = DM_Serif_Display({ subsets: ["latin"], variable: "--gf-dm-serif-display", weight: "400", style: ["normal", "italic"], preload: false });
const bricolage = Bricolage_Grotesque({ subsets: ["latin"], variable: "--gf-bricolage", preload: false });
const outfit = Outfit({ subsets: ["latin"], variable: "--gf-outfit", preload: false });
const archivo = Archivo({ subsets: ["latin"], variable: "--gf-archivo", preload: false });
const archivoBlack = Archivo_Black({ subsets: ["latin"], variable: "--gf-archivo-black", weight: "400", preload: false });

const fontVars = [
  fraunces, inter, mono, cormorant, plex, space, dmSans, syne, manrope,
  instrument, playfair, newsreader, dmSerif, bricolage, outfit, archivo, archivoBlack,
]
  .map((f) => f.variable)
  .join(" ");

export const metadata: Metadata = {
  title: "Growth OS — Template Library",
  description:
    "23 finished business websites · 5 industries · 5 tier steps · 7 genome switches · 6 editions · 344-module playbook · 2 module-built from the factory kit. One click re-forges the whole system — live.",
  keywords: ["Growth OS", "template library", "business websites", "module playbook", "genome", "tiers"],
};

export const viewport: Viewport = {
  colorScheme: "light dark",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f7f4ee" },
    { media: "(prefers-color-scheme: dark)", color: "#14110c" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={fontVars}>
      <body className="antialiased">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
