/*
# Create page compositions table

1. New Tables
- `page_compositions`
  - `id` (uuid, primary key, generated)
  - `name` (text, page name shown in the builder, defaults to "Untitled page")
  - `modules` (jsonb, ordered list of placed modules with their text edits)
  - `created_at` / `updated_at` (timestamptz)

2. Security
- Row level security enabled on `page_compositions`.
- The app has no sign-in, so the anon key reads and writes saved layouts. Access is granted to `anon` and `authenticated` only for SELECT, INSERT and UPDATE. Layouts are intentionally shared across the workspace.
- DELETE is not granted; saved layouts are overwritten rather than removed.

3. Notes
- No existing tables are changed.
*/

CREATE TABLE IF NOT EXISTS page_compositions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Untitled page',
  modules jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE page_compositions ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON page_compositions TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_page_compositions" ON page_compositions;
CREATE POLICY "anon_select_page_compositions" ON page_compositions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_page_compositions" ON page_compositions;
CREATE POLICY "anon_insert_page_compositions" ON page_compositions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_page_compositions" ON page_compositions;
CREATE POLICY "anon_update_page_compositions" ON page_compositions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
