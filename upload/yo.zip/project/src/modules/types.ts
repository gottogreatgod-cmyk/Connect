import type { ComponentType } from 'react';

export type SectionId =
  | 'global'
  | 'hero'
  | 'value'
  | 'proof'
  | 'conversion'
  | 'commerce'
  | 'booking'
  | 'location'
  | 'content'
  | 'people'
  | 'hospitality'
  | 'property'
  | 'automotive'
  | 'education'
  | 'events'
  | 'b2b'
  | 'regulated'
  | 'nonprofit'
  | 'motion'
  | 'forms';

export type Tier = 'Starter' | 'Growth' | 'Business' | 'Flagship';

export interface SectionMeta {
  id: SectionId;
  title: string;
  description: string;
}

export interface ModuleDefinition {
  id: string;
  name: string;
  section: SectionId;
  tier: Tier;
  purpose: string;
  // Each module declares its own props, so the registry stores them type-erased.
  /* eslint-disable @typescript-eslint/no-explicit-any */
  defaults: Record<string, any>;
  component: ComponentType<any>;
  /* eslint-enable @typescript-eslint/no-explicit-any */
}
