import type { ModuleDefinition } from '@/modules/types';
import { conversionModules } from '@/modules/sections/conversion';
import { contentModules } from '@/modules/sections/content';
import { globalModules } from '@/modules/sections/global';
import { heroModules } from '@/modules/sections/hero';
import { hospitalityModules } from '@/modules/sections/hospitality';
import { locationModules } from '@/modules/sections/location';
import { motionModules } from '@/modules/sections/motion';
import { peopleModules } from '@/modules/sections/people';
import { proofModules } from '@/modules/sections/proof';
import { valueModules } from '@/modules/sections/value';

export const MODULES: ModuleDefinition[] = [
  ...globalModules,
  ...heroModules,
  ...valueModules,
  ...proofModules,
  ...conversionModules,
  ...contentModules,
  ...peopleModules,
  ...locationModules,
  ...hospitalityModules,
  ...motionModules,
];

const modulesById = new Map<string, ModuleDefinition>();
for (const module of MODULES) {
  if (modulesById.has(module.id)) {
    throw new Error(`Duplicate module id: ${module.id}`);
  }
  modulesById.set(module.id, module);
}

export function getModule(id: string): ModuleDefinition | undefined {
  return modulesById.get(id);
}
