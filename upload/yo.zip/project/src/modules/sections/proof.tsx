import { ChevronLeft, ChevronRight, Pause, Play, Quote, ShieldCheck, Star } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { ModuleDefinition } from '@/modules/types';
import { usePrefersReducedMotion } from '@/modules/hooks';
import { Container, buttonPrimary } from '@/modules/ui/primitives';
import { CountUp } from '@/modules/ui/CountUp';

interface TrustBarProps {
  label: string;
  items: string[];
}

export function TrustBar({ label, items }: TrustBarProps) {
  return (
    <section aria-label="Trust indicators" className="border-y border-stone-200 bg-white py-8">
      <Container className="flex flex-col items-center gap-6 md:flex-row md:justify-between">
        <p className="text-sm font-medium text-stone-600">{label}</p>
        <ul className="flex flex-wrap justify-center gap-x-8 gap-y-3">
          {items.map((item) => (
            <li key={item} className="flex items-center gap-2 text-sm text-stone-800">
              <ShieldCheck className="h-4 w-4 text-emerald-800" aria-hidden="true" />
              {item}
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}

interface LogoCloudProps {
  label: string;
  logos: string[];
}

export function LogoCloud({ label, logos }: LogoCloudProps) {
  const reduced = usePrefersReducedMotion();
  const track = [...logos, ...logos];

  return (
    <section aria-label={label} className="overflow-hidden bg-stone-50 py-10">
      <p className="mb-6 text-center text-xs font-semibold uppercase tracking-[0.18em] text-stone-600">{label}</p>
      <div className="group relative flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_12%,black_88%,transparent)]">
        <ul className={`flex shrink-0 items-center gap-16 pr-16 ${reduced ? 'flex-wrap justify-center' : 'animate-marquee group-hover:[animation-play-state:paused]'}`}>
          {(reduced ? logos : track).map((logo, index) => (
            <li
              key={`${logo}-${index}`}
              aria-hidden={index >= logos.length ? true : undefined}
              className="whitespace-nowrap font-display text-2xl text-stone-500"
            >
              {logo}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

interface Review {
  quote: string;
  name: string;
  role: string;
  rating: number;
}

interface ReviewCarouselProps {
  heading: string;
  reviews: Review[];
}

export function ReviewCarousel({ heading, reviews }: ReviewCarouselProps) {
  const reduced = usePrefersReducedMotion();
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const count = reviews.length;
  const current = reviews[index % count];

  useEffect(() => {
    if (reduced || paused || count < 2) return;
    const timer = window.setInterval(() => setIndex((value) => (value + 1) % count), 6000);
    return () => window.clearInterval(timer);
  }, [reduced, paused, count]);

  if (!current) return null;

  const step = (delta: number) => setIndex((value) => (value + delta + count) % count);

  return (
    <section
      id="reviews"
      className="bg-stone-900 py-20 text-stone-100 md:py-28"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
    >
      <Container className="max-w-3xl text-center">
        <h2 className="font-display text-3xl text-white md:text-4xl">{heading}</h2>
        <div aria-live="polite" className="mt-12">
          <Quote className="mx-auto h-8 w-8 text-emerald-400" aria-hidden="true" />
          <div className="mt-6 flex justify-center gap-1" aria-label={`${current.rating} out of 5 stars`}>
            {Array.from({ length: 5 }).map((_, star) => (
              <Star
                key={star}
                className={`h-4 w-4 ${star < current.rating ? 'fill-emerald-400 text-emerald-400' : 'text-stone-600'}`}
                aria-hidden="true"
              />
            ))}
          </div>
          <blockquote className="mt-6 font-display text-2xl leading-[1.3] text-white md:text-3xl">
            &ldquo;{current.quote}&rdquo;
          </blockquote>
          <p className="mt-6 text-sm text-stone-300">
            <span className="font-semibold text-white">{current.name}</span> · {current.role}
          </p>
        </div>
        <div className="mt-10 flex items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => step(-1)}
            aria-label="Previous review"
            className="rounded-full border border-stone-600 p-2.5 text-stone-100 transition-colors hover:border-stone-300 hover:bg-stone-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={() => setPaused((value) => !value)}
            aria-label={paused ? 'Resume rotation' : 'Pause rotation'}
            className="rounded-full border border-stone-600 p-2.5 text-stone-100 transition-colors hover:border-stone-300 hover:bg-stone-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            {paused ? <Play className="h-4 w-4" aria-hidden="true" /> : <Pause className="h-4 w-4" aria-hidden="true" />}
          </button>
          <button
            type="button"
            onClick={() => step(1)}
            aria-label="Next review"
            className="rounded-full border border-stone-600 p-2.5 text-stone-100 transition-colors hover:border-stone-300 hover:bg-stone-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            <ChevronRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </Container>
    </section>
  );
}

interface Stat {
  value: number;
  suffix: string;
  label: string;
}

interface ResultsStatStripProps {
  stats: Stat[];
}

export function ResultsStatStrip({ stats }: ResultsStatStripProps) {
  return (
    <section aria-label="Results" className="bg-white py-16">
      <Container>
        <dl className="grid grid-cols-2 gap-10 text-center md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label}>
              <dt className="text-sm text-stone-700">{stat.label}</dt>
              <dd className="mt-2 font-display text-4xl text-emerald-800 md:text-5xl">
                <CountUp value={stat.value} suffix={stat.suffix} />
              </dd>
            </div>
          ))}
        </dl>
      </Container>
    </section>
  );
}

interface GuaranteePanelProps {
  title: string;
  body: string;
  terms: string[];
  ctaLabel: string;
  ctaHref: string;
}

export function GuaranteePanel({ title, body, terms, ctaLabel, ctaHref }: GuaranteePanelProps) {
  return (
    <section className="bg-stone-50 py-16 md:py-20">
      <Container>
        <div className="grid gap-10 rounded-3xl border border-stone-200 bg-white p-8 md:grid-cols-[1fr_auto] md:items-center md:p-12">
          <div>
            <ShieldCheck className="h-8 w-8 text-emerald-800" aria-hidden="true" />
            <h2 className="mt-4 font-display text-2xl text-stone-900 md:text-3xl">{title}</h2>
            <p className="mt-3 max-w-xl text-sm leading-[1.5] text-stone-700">{body}</p>
            <ul className="mt-5 list-disc space-y-2 pl-5 text-sm text-stone-700">
              {terms.map((term) => (
                <li key={term}>{term}</li>
              ))}
            </ul>
          </div>
          <a href={ctaHref} className={buttonPrimary}>
            {ctaLabel}
          </a>
        </div>
      </Container>
    </section>
  );
}

export const proofModules: ModuleDefinition[] = [
  {
    id: 'trust-bar',
    name: 'Trust bar',
    section: 'proof',
    tier: 'Starter',
    purpose: 'Slim row of credentials or guarantees placed directly under a hero.',
    defaults: {
      label: 'Trusted and certified',
      items: ['Fully insured', 'Data protected', 'Local team', '5-star rated'],
    },
    component: TrustBar,
  },
  {
    id: 'logo-cloud',
    name: 'Logo marquee',
    section: 'proof',
    tier: 'Growth',
    purpose: 'Scrolling strip of client or partner names. Pauses on hover and stays still for reduced motion.',
    defaults: {
      label: 'Businesses we have helped grow',
      logos: ['Harbour & Co', 'Meadow Cafe', 'Lumen Dental', 'Ironside Gym', 'Fable Bakery', 'Quarry Books'],
    },
    component: LogoCloud,
  },
  {
    id: 'review-carousel',
    name: 'Review carousel',
    section: 'proof',
    tier: 'Growth',
    purpose: 'Rotating customer quotes with star ratings, manual controls and pause on hover or focus.',
    defaults: {
      heading: 'What our clients say',
      reviews: [
        {
          quote: 'The new site brought in more booking requests in the first month than the old one did all year.',
          name: 'Amara Osei',
          role: 'Owner, Meadow Cafe',
          rating: 5,
        },
        {
          quote: 'They explained every step, delivered on time and made updating our menu something I can do myself.',
          name: 'Daniel Reyes',
          role: 'Director, Lumen Dental',
          rating: 5,
        },
        {
          quote: 'Clear design, fast pages and a team that actually answers the phone. Exactly what we needed.',
          name: 'Priya Natarajan',
          role: 'Founder, Fable Bakery',
          rating: 4,
        },
      ],
    },
    component: ReviewCarousel,
  },
  {
    id: 'results-stat-strip',
    name: 'Results strip',
    section: 'proof',
    tier: 'Growth',
    purpose: 'Four headline numbers that count up when scrolled into view.',
    defaults: {
      stats: [
        { value: 120, suffix: '+', label: 'Projects delivered' },
        { value: 98, suffix: '%', label: 'Clients who renew' },
        { value: 4, suffix: 'x', label: 'Average enquiry growth' },
        { value: 14, suffix: ' days', label: 'Median time to launch' },
      ],
    },
    component: ResultsStatStrip,
  },
  {
    id: 'guarantee-panel',
    name: 'Guarantee panel',
    section: 'proof',
    tier: 'Business',
    purpose: 'Boxed promise with listed terms and a closing call to action.',
    defaults: {
      title: 'Happy with the first draft, or we keep working until you are.',
      body: 'Every project includes two rounds of revisions. If the site does not match the agreed brief at launch, we fix it at no extra cost.',
      terms: ['Two revision rounds included', 'Written brief signed before design starts', '30-day launch support'],
      ctaLabel: 'Read our terms',
      ctaHref: '#terms',
    },
    component: GuaranteePanel,
  },
];
