import { useEffect, useId, useRef, useState, type CSSProperties, type KeyboardEvent, type PointerEvent } from 'react';
import type { ModuleDefinition } from '@/modules/types';
import { Container, SectionHeading, headingClass, bodyClass } from '@/modules/ui/primitives';
import { usePrefersReducedMotion } from '@/modules/hooks';

interface Spin3DProps {
  eyebrow: string;
  title: string;
  body: string;
  faces: string;
}

const CUBE_FACES = [
  'translateZ(90px)',
  'rotateY(90deg) translateZ(90px)',
  'rotateY(180deg) translateZ(90px)',
  'rotateY(-90deg) translateZ(90px)',
];

function Spin3DShowcase({ eyebrow, title, body, faces }: Spin3DProps) {
  const reduced = usePrefersReducedMotion();
  const [angle, setAngle] = useState(0);
  const [hovered, setHovered] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; angle: number } | null>(null);
  const labels = faces.split(',').map((f) => f.trim()).filter(Boolean).slice(0, 4);

  useEffect(() => {
    if (reduced || hovered || dragStart) return;
    let frame = 0;
    let last = performance.now();
    const tick = (now: number) => {
      setAngle((a) => (a + (now - last) * 0.03) % 360);
      last = now;
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [reduced, hovered, dragStart]);

  function handlePointerDown(event: PointerEvent<HTMLDivElement>) {
    event.currentTarget.setPointerCapture(event.pointerId);
    setDragStart({ x: event.clientX, angle });
  }

  function handlePointerMove(event: PointerEvent<HTMLDivElement>) {
    if (!dragStart) return;
    setAngle(dragStart.angle + (event.clientX - dragStart.x) * 0.6);
  }

  function endDrag() {
    setDragStart(null);
  }

  return (
    <section className="bg-stone-900 py-24 text-stone-50">
      <Container>
        <div className="grid items-center gap-16 lg:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-300">{eyebrow}</p>
            <h2 className={`${headingClass} mt-4 text-4xl text-white sm:text-5xl`}>{title}</h2>
            <p className="mt-6 max-w-lg text-lg leading-relaxed text-stone-300">{body}</p>
          </div>
          <div className="flex h-80 flex-col items-center justify-center gap-6 [perspective:800px]">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-stone-400">
              {dragStart ? 'Release to continue' : 'Drag to rotate, hover to hold'}
            </p>
            <div
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={endDrag}
              onPointerCancel={endDrag}
              onPointerEnter={() => setHovered(true)}
              onPointerLeave={() => setHovered(false)}
              className="relative h-44 w-44 cursor-grab touch-none select-none [transform-style:preserve-3d] active:cursor-grabbing"
              style={{ transform: `rotateX(-18deg) rotateY(${angle}deg)` }}
            >
              {CUBE_FACES.map((transform, i) => (
                <div
                  key={transform}
                  className="absolute inset-0 flex items-center justify-center rounded-2xl border border-emerald-300/40 bg-emerald-400/20 p-4 text-center text-sm font-semibold text-white backdrop-blur-sm"
                  style={{ transform } as CSSProperties}
                >
                  {labels[i] ?? ''}
                </div>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

interface TiltCardProps {
  eyebrow: string;
  title: string;
  body: string;
  cta: string;
}

const IDLE_TILT = { rx: 0, ry: 0, glareX: 50, glareY: 50, active: false };

function TiltCard({ eyebrow, title, body, cta }: TiltCardProps) {
  const reduced = usePrefersReducedMotion();
  const [tilt, setTilt] = useState(IDLE_TILT);

  function handleMove(event: PointerEvent<HTMLDivElement>) {
    if (reduced) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const px = (event.clientX - rect.left) / rect.width;
    const py = (event.clientY - rect.top) / rect.height;
    setTilt({ rx: (0.5 - py) * 18, ry: (px - 0.5) * 18, glareX: px * 100, glareY: py * 100, active: true });
  }

  const lifted = tilt.active ? -8 : 0;

  return (
    <section className="bg-stone-50 py-24">
      <Container>
        <SectionHeading eyebrow={eyebrow} title={title} />
        <div className="mt-12 flex justify-center [perspective:1000px]">
          <div
            onPointerMove={handleMove}
            onPointerLeave={() => setTilt(IDLE_TILT)}
            style={{
              transform: `rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg) translateY(${lifted}px)`,
              transition: 'transform 250ms ease-out, box-shadow 250ms ease-out',
            }}
            className="relative w-full max-w-md overflow-hidden rounded-3xl bg-emerald-950 p-10 text-white shadow-2xl shadow-emerald-950/30 will-change-transform"
          >
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 transition-opacity duration-300"
              style={{
                opacity: tilt.active ? 1 : 0,
                background: `radial-gradient(circle at ${tilt.glareX}% ${tilt.glareY}%, rgba(255,255,255,0.22), transparent 55%)`,
              }}
            />
            <div className="relative">
              <h3 className="font-display text-2xl text-white">{title}</h3>
              <p className="mt-4 text-base leading-[1.5] text-emerald-100">{body}</p>
              <button
                type="button"
                className="mt-8 rounded-full bg-white px-6 py-3 text-sm font-semibold text-stone-900 transition hover:bg-emerald-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-emerald-950"
              >
                {cta}
              </button>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

interface TabsProps {
  eyebrow: string;
  title: string;
  tabs: string;
  bodies: string;
}

function InteractiveTabs({ eyebrow, title, tabs, bodies }: TabsProps) {
  const labels = tabs.split('|').map((t) => t.trim()).filter(Boolean);
  const panels = bodies.split('|').map((t) => t.trim());
  const [active, setActive] = useState(0);
  const baseId = useId();

  function handleKeyDown(event: KeyboardEvent<HTMLButtonElement>) {
    const step = event.key === 'ArrowDown' ? 1 : event.key === 'ArrowUp' ? -1 : 0;
    if (step === 0) return;
    event.preventDefault();
    const next = (active + step + labels.length) % labels.length;
    setActive(next);
    document.getElementById(`${baseId}-tab-${next}`)?.focus();
  }

  return (
    <section className="bg-white py-24">
      <Container>
        <SectionHeading eyebrow={eyebrow} title={title} />
        <div className="mt-12 grid gap-8 md:grid-cols-[240px_1fr]">
          <div role="tablist" aria-orientation="vertical" className="flex flex-col gap-2">
            {labels.map((label, i) => (
              <button
                key={label}
                id={`${baseId}-tab-${i}`}
                type="button"
                role="tab"
                aria-selected={active === i}
                aria-controls={`${baseId}-panel`}
                tabIndex={active === i ? 0 : -1}
                onKeyDown={handleKeyDown}
                onClick={() => setActive(i)}
                className={`rounded-xl px-4 py-3 text-left text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
                  active === i ? 'bg-emerald-800 text-white' : 'bg-stone-100 text-stone-800 hover:bg-stone-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <div
            id={`${baseId}-panel`}
            role="tabpanel"
            aria-labelledby={`${baseId}-tab-${active}`}
            className="rounded-2xl border border-stone-200 bg-stone-50 p-8"
          >
            <p key={active} className={`${bodyClass} animate-fade-in`}>
              {panels[active] ?? ''}
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}

interface CalculatorProps {
  eyebrow: string;
  title: string;
  hourlyValue: number;
  hoursSaved: number;
  currency: string;
}

function RoiCalculator({ eyebrow, title, hourlyValue, hoursSaved, currency }: CalculatorProps) {
  const [hours, setHours] = useState(hoursSaved);
  const [rate, setRate] = useState(hourlyValue);
  const yearly = Math.round(hours * rate * 52);
  const resultRef = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    resultRef.current?.animate(
      [{ transform: 'scale(0.96)', opacity: 0.6 }, { transform: 'scale(1)', opacity: 1 }],
      { duration: 200, easing: 'ease-out' },
    );
  }, [yearly]);

  return (
    <section className="bg-stone-50 py-24">
      <Container>
        <SectionHeading eyebrow={eyebrow} title={title} />
        <div className="mt-12 grid gap-10 rounded-3xl bg-white p-10 shadow-sm md:grid-cols-2">
          <div className="space-y-8">
            <label className="block">
              <span className="text-sm font-semibold text-stone-800">Hours saved per week: {hours}</span>
              <input
                type="range"
                min={1}
                max={40}
                value={hours}
                onChange={(e) => setHours(Number(e.target.value))}
                className="mt-3 w-full accent-emerald-800"
              />
            </label>
            <label className="block">
              <span className="text-sm font-semibold text-stone-800">
                Hourly value ({currency}): {rate}
              </span>
              <input
                type="range"
                min={10}
                max={200}
                value={rate}
                onChange={(e) => setRate(Number(e.target.value))}
                className="mt-3 w-full accent-emerald-800"
              />
            </label>
          </div>
          <div className="flex flex-col justify-center rounded-2xl bg-emerald-50 p-8">
            <p className="text-sm font-semibold text-emerald-900">Estimated yearly value</p>
            <p ref={resultRef} aria-live="polite" className="mt-2 font-display text-5xl text-emerald-950">
              {currency}
              {yearly.toLocaleString()}
            </p>
            <p className="mt-3 text-sm text-stone-700">Based on 52 weeks a year.</p>
          </div>
        </div>
      </Container>
    </section>
  );
}

export const motionModules: ModuleDefinition[] = [
  {
    id: 'spin-3d-showcase',
    name: '3D spinning showcase',
    section: 'motion',
    tier: 'Flagship',
    purpose: 'A rotating three-dimensional cube that presents four highlights. Drag to turn it.',
    defaults: {
      eyebrow: 'Interactive showcase',
      title: 'See it from every angle',
      body: 'Each face of the display carries one of the core promises of your offer.',
      faces: 'Fast,Clear,Trusted,Yours',
    },
    component: Spin3DShowcase,
  },
  {
    id: 'tilt-3d-card',
    name: '3D tilt card',
    section: 'motion',
    tier: 'Flagship',
    purpose: 'A card that tilts and lights up under the pointer for a physical, responsive feel.',
    defaults: {
      eyebrow: 'Feature',
      title: 'Move your cursor over the card',
      body: 'The card responds to your pointer with a three-dimensional tilt and a soft highlight.',
      cta: 'Get started',
    },
    component: TiltCard,
  },
  {
    id: 'interactive-tabs',
    name: 'Interactive tabs',
    section: 'motion',
    tier: 'Flagship',
    purpose: 'Switch between related topics without leaving the page. Arrow keys move between tabs.',
    defaults: {
      eyebrow: 'Explore',
      title: 'Choose a topic',
      tabs: 'Setup|Results|Support',
      bodies: 'Setup takes minutes with guided steps.|Results are tracked from day one.|Support is available every working day.',
    },
    component: InteractiveTabs,
  },
  {
    id: 'roi-calculator',
    name: 'Value calculator',
    section: 'motion',
    tier: 'Flagship',
    purpose: 'Visitors adjust sliders to estimate the yearly value of your offer.',
    defaults: {
      eyebrow: 'Calculator',
      title: 'What could you gain?',
      hourlyValue: 45,
      hoursSaved: 6,
      currency: '$',
    },
    component: RoiCalculator,
  },
];
