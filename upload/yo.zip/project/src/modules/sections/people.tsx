import type { ModuleDefinition } from '@/modules/types';
import { Container, SectionHeading } from '@/modules/ui/primitives';

interface TeamMember {
  name: string;
  role: string;
  bio: string;
  imageUrl: string;
  imageAlt: string;
}

interface TeamGridProps {
  eyebrow: string;
  heading: string;
  intro: string;
  members: TeamMember[];
}

export function TeamGrid({ eyebrow, heading, intro, members }: TeamGridProps) {
  return (
    <section id="team" className="bg-stone-50 py-20 md:py-28">
      <Container>
        <SectionHeading eyebrow={eyebrow} title={heading} intro={intro} />
        <ul className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {members.map((member) => (
            <li key={member.name} className="group">
              <div className="overflow-hidden rounded-2xl bg-stone-200">
                <img
                  src={member.imageUrl}
                  alt={member.imageAlt}
                  loading="lazy"
                  className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
              </div>
              <h3 className="mt-5 font-display text-xl text-stone-900">{member.name}</h3>
              <p className="mt-1.5 text-sm font-medium text-emerald-800">{member.role}</p>
              <p className="mt-3 text-sm leading-[1.5] text-stone-700">{member.bio}</p>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}

export const peopleModules: ModuleDefinition[] = [
  {
    id: 'team-grid',
    name: 'Team grid',
    section: 'people',
    tier: 'Growth',
    purpose: 'Portrait cards with role and a short bio, arranged in a responsive grid.',
    defaults: {
      eyebrow: 'The people',
      heading: 'A small team with a big stake in your success.',
      intro: 'You will work directly with the people who design and build your site.',
      members: [
        {
          name: 'Marcus Hale',
          role: 'Founder and creative lead',
          bio: 'Twelve years designing brands for independent businesses across the region.',
          imageUrl: 'https://images.pexels.com/photos/5308640/pexels-photo-5308640.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
          imageAlt: 'Portrait of Marcus Hale, a smiling man in a dark blazer',
        },
        {
          name: 'Lena Brooks',
          role: 'Lead developer',
          bio: 'Builds fast, accessible sites and makes sure every page works on every phone.',
          imageUrl: 'https://images.pexels.com/photos/7717254/pexels-photo-7717254.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
          imageAlt: 'Portrait of Lena Brooks smiling against a dark background',
        },
        {
          name: 'Tomas Ibarra',
          role: 'Client success',
          bio: 'Your first call and your monthly check-in. Tomas keeps projects on track.',
          imageUrl: 'https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
          imageAlt: 'Portrait of Tomas Ibarra in a beanie, smiling warmly',
        },
      ],
    },
    component: TeamGrid,
  },
];
