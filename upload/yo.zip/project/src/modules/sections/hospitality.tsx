import type { ModuleDefinition } from '@/modules/types';
import { Container, eyebrowClass } from '@/modules/ui/primitives';

interface MenuItem {
  name: string;
  description: string;
  price: string;
  tags: string[];
}

interface MenuSection {
  title: string;
  items: MenuItem[];
}

interface MenuBoardProps {
  eyebrow: string;
  heading: string;
  imageUrl: string;
  imageAlt: string;
  legend: string;
  sections: MenuSection[];
}

export function MenuBoard({ eyebrow, heading, imageUrl, imageAlt, legend, sections }: MenuBoardProps) {
  return (
    <section id="menu" className="bg-stone-900 py-20 text-stone-100 md:py-28">
      <Container className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
        <div className="lg:sticky lg:top-24 lg:self-start">
          <p className={`${eyebrowClass} text-amber-300`}>{eyebrow}</p>
          <h2 className="mt-3 font-display text-3xl text-white md:text-4xl">{heading}</h2>
          <img
            src={imageUrl}
            alt={imageAlt}
            loading="lazy"
            className="mt-8 aspect-[4/3] w-full rounded-2xl object-cover"
          />
          <p className="mt-6 text-sm text-stone-400">{legend}</p>
        </div>
        <div className="space-y-12">
          {sections.map((section) => (
            <div key={section.title}>
              <h3 className="border-b border-stone-700 pb-3 font-display text-2xl text-white">{section.title}</h3>
              <ul className="mt-6 space-y-7">
                {section.items.map((item) => (
                  <li key={item.name} className="flex gap-6">
                    <div className="flex-1">
                      <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                        <p className="font-medium text-white">{item.name}</p>
                        {item.tags.length > 0 && (
                          <span className="text-xs text-stone-400">({item.tags.join(', ')})</span>
                        )}
                      </div>
                      <p className="mt-1.5 text-sm leading-[1.5] text-stone-300">{item.description}</p>
                    </div>
                    <p className="font-display text-lg text-amber-300">{item.price}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

export const hospitalityModules: ModuleDefinition[] = [
  {
    id: 'menu-board',
    name: 'Menu board',
    section: 'hospitality',
    tier: 'Growth',
    purpose: 'Categorised menu with descriptions, dietary tags and prices beside a feature photograph.',
    defaults: {
      eyebrow: 'Seasonal menu',
      heading: 'Cooked to order, sourced close to home.',
      imageUrl: 'https://images.pexels.com/photos/23644633/pexels-photo-23644633.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
      imageAlt: 'A gourmet appetizer served on a white plate',
      legend: 'V vegetarian, GF gluten free. Please tell us about any allergies before ordering.',
      sections: [
        {
          title: 'Small plates',
          items: [
            { name: 'Charred leeks', description: 'Hazelnut romesco, aged pecorino, crisp shallots.', price: '$12', tags: ['V', 'GF'] },
            { name: 'Seared scallops', description: 'Cauliflower purée, brown butter, pickled raisins.', price: '$18', tags: ['GF'] },
          ],
        },
        {
          title: 'Mains',
          items: [
            { name: 'Slow-braised short rib', description: 'Red wine jus, parsnip, buttered greens.', price: '$32', tags: ['GF'] },
            { name: 'Wild mushroom risotto', description: 'Parmesan, thyme oil, toasted barley.', price: '$24', tags: ['V'] },
          ],
        },
      ],
    },
    component: MenuBoard,
  },
];
