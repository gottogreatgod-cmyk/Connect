import { Clock, MapPin, Navigation, Phone } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { ModuleDefinition } from '@/modules/types';
import { Container, buttonPrimary, buttonSecondary } from '@/modules/ui/primitives';

const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

interface OpeningHour {
  day: string;
  open: string | null;
  close: string | null;
}

function toMinutes(time: string): number {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
}

function todayIndex(): number {
  return (new Date().getDay() + 6) % 7;
}

function useNow(intervalMs: number): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), intervalMs);
    return () => window.clearInterval(timer);
  }, [intervalMs]);
  return now;
}

interface LocationCardProps {
  name: string;
  street: string;
  city: string;
  phone: string;
  directionsHref: string;
  parkingNote: string;
  imageUrl: string;
}

export function LocationCard({ name, street, city, phone, directionsHref, parkingNote, imageUrl }: LocationCardProps) {
  const dialable = phone.replace(/[^+\d]/g, '');

  return (
    <section className="bg-white py-16 md:py-20">
      <Container className="grid gap-10 md:grid-cols-2 md:items-center">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-800">Visit us</p>
          <h2 className="mt-3 font-display text-3xl text-stone-900">{name}</h2>
          <address className="mt-5 flex gap-3 not-italic text-base leading-[1.5] text-stone-700">
            <MapPin className="mt-1 h-5 w-5 shrink-0 text-emerald-800" aria-hidden="true" />
            <span>
              {street}
              <br />
              {city}
            </span>
          </address>
          <p className="mt-4 text-sm text-stone-600">{parkingNote}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a href={directionsHref} className={buttonPrimary}>
              <Navigation className="h-4 w-4" aria-hidden="true" />
              Get directions
            </a>
            <a href={`tel:${dialable}`} className={buttonSecondary}>
              <Phone className="h-4 w-4" aria-hidden="true" />
              {phone}
            </a>
          </div>
        </div>
        <div className="overflow-hidden rounded-3xl border border-stone-200">
          <img
            src={imageUrl}
            alt="Street front with colourful striped awnings and potted plants"
            className="aspect-[4/3] w-full object-cover"
            loading="lazy"
          />
        </div>
      </Container>
    </section>
  );
}

interface HoursTableProps {
  heading: string;
  hours: OpeningHour[];
}

export function HoursTable({ heading, hours }: HoursTableProps) {
  const today = todayIndex();

  return (
    <section className="bg-stone-50 py-16">
      <Container className="max-w-xl">
        <h2 className="flex items-center gap-3 font-display text-2xl text-stone-900">
          <Clock className="h-5 w-5 text-emerald-800" aria-hidden="true" />
          {heading}
        </h2>
        <table className="mt-6 w-full border-collapse text-sm">
          <caption className="sr-only">{heading}</caption>
          <tbody>
            {hours.map((entry, index) => (
              <tr
                key={entry.day}
                aria-current={index === today ? 'date' : undefined}
                className={`border-b border-stone-200 ${index === today ? 'font-semibold text-stone-900' : 'text-stone-700'}`}
              >
                <th scope="row" className="py-3 pr-4 text-left font-medium">
                  {entry.day}
                </th>
                <td className="py-3 text-right">
                  {entry.open && entry.close ? `${entry.open} to ${entry.close}` : 'Closed'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Container>
    </section>
  );
}

interface OpenNowBadgeProps {
  hours: OpeningHour[];
}

export function OpenNowBadge({ hours }: OpenNowBadgeProps) {
  const now = useNow(60_000);
  const todayHours = hours.find((entry) => entry.day === DAY_NAMES[todayIndex()]);
  const minutesNow = now.getHours() * 60 + now.getMinutes();
  const isOpen = todayHours?.open && todayHours.close
    ? minutesNow >= toMinutes(todayHours.open) && minutesNow < toMinutes(todayHours.close)
    : false;

  return (
    <div className="inline-flex items-center gap-2 py-2">
      <span
        className={`inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-sm font-semibold ${
          isOpen ? 'bg-emerald-100 text-emerald-900' : 'bg-stone-200 text-stone-800'
        }`}
      >
        <span
          aria-hidden="true"
          className={`h-2 w-2 rounded-full ${isOpen ? 'bg-emerald-700' : 'bg-stone-500'}`}
        />
        {isOpen ? `Open now, until ${todayHours?.close}` : 'Closed right now'}
      </span>
    </div>
  );
}

export const locationModules: ModuleDefinition[] = [
  {
    id: 'location-card',
    name: 'Location card',
    section: 'location',
    tier: 'Starter',
    purpose: 'Address, parking note, directions button, tap-to-call number and a street photograph.',
    defaults: {
      name: 'Northwind Studio, Riverside',
      street: '48 Mill Lane, Unit 3',
      city: 'Springfield, ST 04821',
      phone: '+1 (555) 014-2290',
      directionsHref: '#directions',
      parkingNote: 'Free parking behind the building, entrance on the courtyard side.',
      imageUrl: 'https://images.pexels.com/photos/8228650/pexels-photo-8228650.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    },
    component: LocationCard,
  },
  {
    id: 'hours-table',
    name: 'Opening hours table',
    section: 'location',
    tier: 'Starter',
    purpose: 'Accessible weekly hours table that highlights today.',
    defaults: {
      heading: 'Opening hours',
      hours: [
        { day: 'Monday', open: '09:00', close: '17:30' },
        { day: 'Tuesday', open: '09:00', close: '17:30' },
        { day: 'Wednesday', open: '09:00', close: '17:30' },
        { day: 'Thursday', open: '09:00', close: '19:00' },
        { day: 'Friday', open: '09:00', close: '17:00' },
        { day: 'Saturday', open: '10:00', close: '14:00' },
        { day: 'Sunday', open: null, close: null },
      ],
    },
    component: HoursTable,
  },
  {
    id: 'open-now-badge',
    name: 'Open now badge',
    section: 'location',
    tier: 'Growth',
    purpose: 'Live badge that reads today’s hours and shows whether the business is open this minute.',
    defaults: {
      hours: [
        { day: 'Monday', open: '09:00', close: '17:30' },
        { day: 'Tuesday', open: '09:00', close: '17:30' },
        { day: 'Wednesday', open: '09:00', close: '17:30' },
        { day: 'Thursday', open: '09:00', close: '19:00' },
        { day: 'Friday', open: '09:00', close: '17:00' },
        { day: 'Saturday', open: '10:00', close: '14:00' },
        { day: 'Sunday', open: null, close: null },
      ],
    },
    component: OpenNowBadge,
  },
];
