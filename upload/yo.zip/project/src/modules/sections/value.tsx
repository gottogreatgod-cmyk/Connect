import { Check, Minus } from 'lucide-react';
import { useState } from 'react';
import type { ModuleDefinition } from '@/modules/types';
import { Container, SectionHeading, buttonPrimary, buttonSecondary } from '@/modules/ui/primitives';

interface BenefitItem {
  title: string;
  detail: string;
}

interface BenefitGridProps {
  eyebrow: string;
  heading: string;
  intro: string;
  items: BenefitItem[];
}

export function BenefitGrid({ eyebrow, heading, intro, items }: BenefitGridProps) {
  return (
    <section id="services" className="bg-white py-20 md:py-28">
      <Container>
        <SectionHeading eyebrow={eyebrow} title={heading} intro={intro} />
        <ul className="mt-16 grid gap-px overflow-hidden rounded-2xl border border-stone-200 bg-stone-200 md:grid-cols-3">
          {items.map((item, index) => (
            <li
              key={item.title}
              className="bg-white p-8 transition-colors hover:bg-stone-50 md:p-10"
            >
              <span className="font-display text-sm text-emerald-800">0{index + 1}</span>
              <h3 className="mt-4 font-display text-xl text-stone-900">{item.title}</h3>
              <p className="mt-3 text-sm leading-[1.5] text-stone-700">{item.detail}</p>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}

interface ProcessStep {
  title: string;
  detail: string;
  duration: string;
}

interface HowItWorksProps {
  heading: string;
  steps: ProcessStep[];
}

export function HowItWorks({ heading, steps }: HowItWorksProps) {
  return (
    <section id="process" className="bg-stone-100 py-20 md:py-28">
      <Container>
        <h2 className="font-display text-3xl text-stone-900 md:text-4xl">{heading}</h2>
        <ol className="mt-14 grid gap-10 md:grid-cols-3 md:gap-8">
          {steps.map((step, index) => (
            <li key={step.title} className="relative border-t-2 border-emerald-800 pt-6">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-stone-600">
                Step {index + 1} · {step.duration}
              </p>
              <h3 className="mt-3 font-display text-xl text-stone-900">{step.title}</h3>
              <p className="mt-3 text-sm leading-[1.5] text-stone-700">{step.detail}</p>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}

interface ComparisonRow {
  feature: string;
  values: string[];
}

interface ComparisonTableProps {
  heading: string;
  columns: string[];
  rows: ComparisonRow[];
}

export function ComparisonTable({ heading, columns, rows }: ComparisonTableProps) {
  return (
    <section className="bg-white py-20">
      <Container>
        <h2 className="font-display text-3xl text-stone-900 md:text-4xl">{heading}</h2>
        <div className="mt-10 overflow-x-auto rounded-2xl border border-stone-200">
          <table className="w-full min-w-[32rem] border-collapse text-left text-sm">
            <thead className="bg-stone-50">
              <tr>
                <th scope="col" className="px-6 py-4 font-semibold text-stone-900">
                  <span className="sr-only">Feature</span>
                </th>
                {columns.map((column) => (
                  <th key={column} scope="col" className="px-6 py-4 font-semibold text-stone-900">
                    {column}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.feature} className="border-t border-stone-200">
                  <th scope="row" className="px-6 py-4 font-medium text-stone-800">
                    {row.feature}
                  </th>
                  {row.values.map((value, index) => (
                    <td key={`${row.feature}-${index}`} className="px-6 py-4 text-stone-700">
                      {value === 'yes' ? (
                        <>
                          <Check className="h-4 w-4 text-emerald-800" aria-hidden="true" />
                          <span className="sr-only">Included</span>
                        </>
                      ) : value === 'no' ? (
                        <>
                          <Minus className="h-4 w-4 text-stone-500" aria-hidden="true" />
                          <span className="sr-only">Not included</span>
                        </>
                      ) : (
                        value
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Container>
    </section>
  );
}

interface Plan {
  name: string;
  monthly: string;
  annual: string;
  summary: string;
  features: string[];
  ctaLabel: string;
  featured: boolean;
}

interface PricingTableProps {
  heading: string;
  intro: string;
  plans: Plan[];
}

export function PricingTable({ heading, intro, plans }: PricingTableProps) {
  const [annual, setAnnual] = useState(false);

  return (
    <section id="pricing" className="bg-stone-50 py-20 md:py-28">
      <Container>
        <SectionHeading title={heading} intro={intro} />
        <div className="mt-10 flex justify-center">
          <button
            type="button"
            aria-pressed={annual}
            onClick={() => setAnnual((value) => !value)}
            className="inline-flex items-center gap-3 rounded-full border border-stone-300 bg-white px-2 py-1.5 text-sm text-stone-800"
          >
            <span className={`rounded-full px-4 py-1.5 transition-colors ${annual ? 'text-stone-600' : 'bg-stone-900 text-white'}`}>
              Monthly
            </span>
            <span className={`rounded-full px-4 py-1.5 transition-colors ${annual ? 'bg-stone-900 text-white' : 'text-stone-600'}`}>
              Annual
            </span>
          </button>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {plans.map((plan) => {
            const price = annual ? plan.annual : plan.monthly;
            const isPriced = price.startsWith('$');

            return (
              <article
                key={plan.name}
                className={`flex flex-col rounded-2xl border bg-white p-8 transition-shadow hover:shadow-lg ${
                  plan.featured ? 'border-emerald-800 shadow-md' : 'border-stone-200'
                }`}
              >
                <h3 className="font-display text-xl text-stone-900">{plan.name}</h3>
                <p className="mt-2 text-sm text-stone-700">{plan.summary}</p>
                <p className="mt-6 font-display text-4xl text-stone-900">
                  {price}
                  {isPriced && (
                    <span className="ml-1 text-sm font-normal text-stone-600">{annual ? '/year' : '/month'}</span>
                  )}
                </p>
                <ul className="mt-6 flex-1 space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex gap-3 text-sm text-stone-700">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-800" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <a href="#contact" className={`${plan.featured ? buttonPrimary : buttonSecondary} mt-8`}>
                  {plan.ctaLabel}
                </a>
              </article>
            );
          })}
        </div>
      </Container>
    </section>
  );
}

export const valueModules: ModuleDefinition[] = [
  {
    id: 'benefit-grid',
    name: 'Benefit grid',
    section: 'value',
    tier: 'Starter',
    purpose: 'Three numbered benefit cards that explain what the visitor gets.',
    defaults: {
      eyebrow: 'Why work with us',
      heading: 'Everything a good website should do, handled.',
      intro: 'Less guesswork for you, and a site that keeps working long after launch.',
      items: [
        { title: 'Clear positioning', detail: 'Headlines and pages that say exactly who you help and why it matters.' },
        { title: 'Fast everywhere', detail: 'Lightweight pages that load quickly on phones and slow connections.' },
        { title: 'Easy to update', detail: 'You can change opening hours, prices and photos without calling a developer.' },
      ],
    },
    component: BenefitGrid,
  },
  {
    id: 'how-it-works',
    name: 'Process timeline',
    section: 'value',
    tier: 'Starter',
    purpose: 'Three-step process strip that removes uncertainty about what happens next.',
    defaults: {
      heading: 'From first call to launch in three steps.',
      steps: [
        { title: 'Discover', detail: 'We learn about your customers, goals and what is not working today.', duration: 'Week 1' },
        { title: 'Design and build', detail: 'You review clickable designs, then we build and test the full site.', duration: 'Weeks 2 to 4' },
        { title: 'Launch and grow', detail: 'We publish, train your team and review results together each month.', duration: 'Week 5 onward' },
      ],
    },
    component: HowItWorks,
  },
  {
    id: 'comparison-table',
    name: 'Comparison table',
    section: 'value',
    tier: 'Growth',
    purpose: 'Feature matrix comparing options, with accessible yes and no markers.',
    defaults: {
      heading: 'See what is included at each level.',
      columns: ['Essentials', 'Professional'],
      rows: [
        { feature: 'Custom design', values: ['yes', 'yes'] },
        { feature: 'Online booking', values: ['no', 'yes'] },
        { feature: 'Monthly analytics report', values: ['no', 'yes'] },
        { feature: 'Support response time', values: ['3 days', 'Same day'] },
      ],
    },
    component: ComparisonTable,
  },
  {
    id: 'pricing-table',
    name: 'Pricing table',
    section: 'value',
    tier: 'Growth',
    purpose: 'Three plans with a monthly and annual switch and a highlighted recommendation.',
    defaults: {
      heading: 'Simple pricing, no surprises.',
      intro: 'Pick the level that fits today and move up when you need more.',
      plans: [
        {
          name: 'Essentials',
          monthly: '$89',
          annual: '$890',
          summary: 'A polished one-page site to get found.',
          features: ['Single page design', 'Mobile optimised', 'Contact form'],
          ctaLabel: 'Choose Essentials',
          featured: false,
        },
        {
          name: 'Professional',
          monthly: '$189',
          annual: '$1,890',
          summary: 'A full site with booking and reporting.',
          features: ['Up to 8 pages', 'Online booking', 'Monthly analytics report', 'Priority support'],
          ctaLabel: 'Choose Professional',
          featured: true,
        },
        {
          name: 'Enterprise',
          monthly: 'Custom',
          annual: 'Custom',
          summary: 'Multi-location and integration work.',
          features: ['Unlimited pages', 'Custom integrations', 'Dedicated account lead'],
          ctaLabel: 'Talk to us',
          featured: false,
        },
      ],
    },
    component: PricingTable,
  },
];
