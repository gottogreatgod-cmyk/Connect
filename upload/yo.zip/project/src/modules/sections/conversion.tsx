import { Mail, Phone, CheckCircle2, Clock, PhoneCall } from 'lucide-react';
import { useId, useState, type FormEvent } from 'react';
import type { ModuleDefinition } from '@/modules/types';
import { Container, FormField, buttonPrimary, eyebrowClass } from '@/modules/ui/primitives';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface PrimaryCtaProps {
  heading: string;
  intro: string;
  buttonLabel: string;
  href: string;
}

export function PrimaryCta({ heading, intro, buttonLabel, href }: PrimaryCtaProps) {
  return (
    <section className="bg-emerald-900 py-20 text-emerald-50">
      <Container className="flex flex-col items-start gap-8 md:flex-row md:items-center md:justify-between">
        <div className="max-w-2xl">
          <h2 className="font-display text-3xl leading-[1.2] text-white md:text-4xl">{heading}</h2>
          <p className="mt-4 text-base leading-[1.5] text-emerald-100">{intro}</p>
        </div>
        <a
          href={href}
          className="inline-flex shrink-0 items-center justify-center rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-emerald-900 shadow-sm transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-emerald-900"
        >
          {buttonLabel}
        </a>
      </Container>
    </section>
  );
}

type ContactValues = { name: string; email: string; phone: string; message: string };
type ContactErrors = Partial<Record<keyof ContactValues | 'consent', string>>;

interface ContactFormProps {
  heading: string;
  intro: string;
  submitLabel: string;
  consentLabel: string;
  successTitle: string;
  successBody: string;
}

const EMPTY_VALUES: ContactValues = { name: '', email: '', phone: '', message: '' };

export function ContactForm({ heading, intro, submitLabel, consentLabel, successTitle, successBody }: ContactFormProps) {
  const uid = useId();
  const [values, setValues] = useState<ContactValues>(EMPTY_VALUES);
  const [consent, setConsent] = useState(false);
  const [errors, setErrors] = useState<ContactErrors>({});
  const [sent, setSent] = useState(false);

  function update(key: keyof ContactValues) {
    return (value: string) => setValues((current) => ({ ...current, [key]: value }));
  }

  function validate(): ContactErrors {
    const found: ContactErrors = {};
    if (values.name.trim().length < 2) found.name = 'Please enter your name.';
    if (!EMAIL_PATTERN.test(values.email.trim())) found.email = 'Please enter a valid email address.';
    if (values.message.trim().length < 10) found.message = 'Tell us a little more, at least 10 characters.';
    if (!consent) found.consent = 'Please agree so we can reply to you.';
    return found;
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const found = validate();
    setErrors(found);
    const firstInvalid = (['name', 'email', 'message', 'consent'] as const).find((key) => found[key]);
    if (firstInvalid) {
      document.getElementById(`${uid}-${firstInvalid}`)?.focus();
      return;
    }
    setSent(true);
  }

  if (sent) {
    return (
      <section id="contact" className="bg-white py-20">
        <Container className="max-w-2xl">
          <div role="status" className="rounded-2xl border border-emerald-200 bg-emerald-50 p-10 text-center">
            <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-800" aria-hidden="true" />
            <h2 className="mt-4 font-display text-2xl text-stone-900">{successTitle}</h2>
            <p className="mt-3 text-sm leading-[1.5] text-stone-700">{successBody}</p>
          </div>
        </Container>
      </section>
    );
  }

  return (
    <section id="contact" className="bg-white py-20 md:py-28">
      <Container className="grid gap-12 lg:grid-cols-[1fr_1.2fr] lg:gap-20">
        <div>
          <p className={eyebrowClass}>Get in touch</p>
          <h2 className="mt-3 font-display text-3xl text-stone-900 md:text-4xl">{heading}</h2>
          <p className="mt-4 text-base leading-[1.5] text-stone-700">{intro}</p>
        </div>
        <form noValidate onSubmit={handleSubmit} className="space-y-5 rounded-2xl border border-stone-200 bg-stone-50 p-6 md:p-8">
          <div className="grid gap-5 sm:grid-cols-2">
            <FormField
              id={`${uid}-name`}
              label="Full name"
              value={values.name}
              onChange={update('name')}
              autoComplete="name"
              required
              error={errors.name}
            />
            <FormField
              id={`${uid}-email`}
              label="Email"
              type="email"
              value={values.email}
              onChange={update('email')}
              autoComplete="email"
              required
              error={errors.email}
            />
          </div>
          <FormField
            id={`${uid}-phone`}
            label="Phone (optional)"
            type="tel"
            value={values.phone}
            onChange={update('phone')}
            autoComplete="tel"
          />
          <FormField
            id={`${uid}-message`}
            label="How can we help?"
            multiline
            value={values.message}
            onChange={update('message')}
            required
            hint="Share your goals, timing and anything we should know."
            error={errors.message}
          />
          <div>
            <label className="flex items-start gap-3 text-sm text-stone-700">
              <input
                id={`${uid}-consent`}
                type="checkbox"
                checked={consent}
                onChange={(event) => setConsent(event.target.checked)}
                aria-invalid={errors.consent ? true : undefined}
                aria-describedby={errors.consent ? `${uid}-consent-error` : undefined}
                className="mt-1 h-4 w-4 rounded border-stone-400 text-emerald-800 focus:ring-emerald-700"
              />
              <span>{consentLabel}</span>
            </label>
            {errors.consent && (
              <p id={`${uid}-consent-error`} className="mt-1.5 text-xs font-medium text-rose-700">
                {errors.consent}
              </p>
            )}
          </div>
          <button type="submit" className={`${buttonPrimary} w-full sm:w-auto`}>
            {submitLabel}
          </button>
        </form>
      </Container>
    </section>
  );
}

interface NewsletterSignupProps {
  heading: string;
  intro: string;
  buttonLabel: string;
  successMessage: string;
}

export function NewsletterSignup({ heading, intro, buttonLabel, successMessage }: NewsletterSignupProps) {
  const uid = useId();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | undefined>();
  const [done, setDone] = useState(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!EMAIL_PATTERN.test(email.trim())) {
      setError('Please enter a valid email address.');
      return;
    }
    setError(undefined);
    setDone(true);
  }

  return (
    <section className="bg-stone-100 py-16">
      <Container className="grid items-center gap-8 md:grid-cols-2">
        <div>
          <Mail className="h-6 w-6 text-emerald-800" aria-hidden="true" />
          <h2 className="mt-4 font-display text-2xl text-stone-900 md:text-3xl">{heading}</h2>
          <p className="mt-3 text-sm leading-[1.5] text-stone-700">{intro}</p>
        </div>
        {done ? (
          <p role="status" className="rounded-xl border border-emerald-200 bg-white p-5 text-sm font-medium text-emerald-900">
            {successMessage}
          </p>
        ) : (
          <form noValidate onSubmit={handleSubmit} className="flex flex-col gap-3 sm:flex-row sm:items-start">
            <div className="flex-1">
              <FormField
                id={`${uid}-email`}
                label="Email address"
                type="email"
                value={email}
                onChange={setEmail}
                autoComplete="email"
                required
                error={error}
              />
            </div>
            <button type="submit" className={`${buttonPrimary} sm:mt-8`}>
              {buttonLabel}
            </button>
          </form>
        )}
      </Container>
    </section>
  );
}

interface CallNowPanelProps {
  heading: string;
  phone: string;
  hoursNote: string;
  emergencyNote: string;
}

export function CallNowPanel({ heading, phone, hoursNote, emergencyNote }: CallNowPanelProps) {
  const dialable = phone.replace(/[^+\d]/g, '');

  return (
    <section className="bg-white py-16">
      <Container>
        <div className="flex flex-col gap-6 rounded-3xl bg-stone-900 p-8 text-white md:flex-row md:items-center md:justify-between md:p-12">
          <div>
            <h2 className="font-display text-2xl md:text-3xl">{heading}</h2>
            <p className="mt-3 flex items-center gap-2 text-sm text-stone-300">
              <Clock className="h-4 w-4" aria-hidden="true" />
              {hoursNote}
            </p>
            <p className="mt-2 text-sm text-stone-400">{emergencyNote}</p>
          </div>
          <a
            href={`tel:${dialable}`}
            className="inline-flex shrink-0 items-center gap-3 rounded-full bg-white px-7 py-3.5 text-base font-semibold text-stone-900 transition-colors hover:bg-emerald-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            <Phone className="h-5 w-5" aria-hidden="true" />
            {phone}
          </a>
        </div>
      </Container>
    </section>
  );
}

interface StickyActionBarProps {
  phone: string;
  ctaLabel: string;
  ctaHref: string;
}

export function StickyActionBar({ phone, ctaLabel, ctaHref }: StickyActionBarProps) {
  const dialable = phone.replace(/[^+\d]/g, '');

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 gap-px border-t border-stone-200 bg-stone-200 shadow-[0_-4px_16px_rgba(0,0,0,0.06)] md:hidden">
      <a href={`tel:${dialable}`} className="flex items-center justify-center gap-2 bg-white py-4 text-sm font-semibold text-stone-900">
        <PhoneCall className="h-4 w-4" aria-hidden="true" />
        Call now
      </a>
      <a href={ctaHref} className="flex items-center justify-center bg-emerald-800 py-4 text-sm font-semibold text-white">
        {ctaLabel}
      </a>
    </div>
  );
}

export const conversionModules: ModuleDefinition[] = [
  {
    id: 'primary-cta',
    name: 'Call-to-action band',
    section: 'conversion',
    tier: 'Starter',
    purpose: 'Full-width banner that closes a page with one clear action.',
    defaults: {
      heading: 'Ready to see what your new website could do?',
      intro: 'Book a free 30-minute review. We will look at your current site and tell you honestly what to change.',
      buttonLabel: 'Book a free review',
      href: '#contact',
    },
    component: PrimaryCta,
  },
  {
    id: 'contact-form',
    name: 'Contact form',
    section: 'conversion',
    tier: 'Starter',
    purpose: 'Validated enquiry form with inline errors, a consent checkbox and a confirmation state.',
    defaults: {
      heading: 'Tell us about your project',
      intro: 'Send a few details and a real person will reply within one working day.',
      submitLabel: 'Send enquiry',
      consentLabel: 'I agree to be contacted about my enquiry and understand my details are used only for that purpose.',
      successTitle: 'Thank you, your message is on its way.',
      successBody: 'We will reply within one working day. Check your inbox for a confirmation.',
    },
    component: ContactForm,
  },
  {
    id: 'newsletter-signup',
    name: 'Newsletter sign-up',
    section: 'conversion',
    tier: 'Starter',
    purpose: 'Compact email capture with validation and a success message.',
    defaults: {
      heading: 'Monthly notes on running a better local business online',
      intro: 'One short email a month. No spam, unsubscribe in a single click.',
      buttonLabel: 'Subscribe',
      successMessage: 'You are subscribed. Look out for the next issue.',
    },
    component: NewsletterSignup,
  },
  {
    id: 'call-now-panel',
    name: 'Call now panel',
    section: 'conversion',
    tier: 'Starter',
    purpose: 'High-contrast phone panel with opening note and a tap-to-call button.',
    defaults: {
      heading: 'Prefer to talk it through?',
      phone: '+1 (555) 014-2290',
      hoursNote: 'Mon to Fri, 9:00 to 17:30',
      emergencyNote: 'Out of hours? Leave a message and we will call back the next working day.',
    },
    component: CallNowPanel,
  },
  {
    id: 'sticky-action-bar',
    name: 'Mobile sticky action bar',
    section: 'conversion',
    tier: 'Growth',
    purpose: 'Fixed bottom bar on phones with call and booking buttons. Hidden on larger screens.',
    defaults: {
      phone: '+1 (555) 014-2290',
      ctaLabel: 'Book now',
      ctaHref: '#contact',
    },
    component: StickyActionBar,
  },
];
