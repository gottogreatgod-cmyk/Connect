import { useEffect, useState } from 'react';
import { ArrowUp, Cookie, Menu, Megaphone, X } from 'lucide-react';
import type { ModuleDefinition } from '@/modules/types';
import { Container, buttonPrimary, buttonSecondary } from '@/modules/ui/primitives';

interface NavItem {
  label: string;
  href: string;
}

interface SiteHeaderProps {
  brand: string;
  nav: NavItem[];
  ctaLabel: string;
  ctaHref: string;
}

export function SiteHeader({ brand, nav, ctaLabel, ctaHref }: SiteHeaderProps) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <header className="sticky top-0 z-40 border-b border-stone-200 bg-white/95 backdrop-blur">
      <Container className="flex h-16 items-center gap-8">
        <a href="#top" className="font-display text-lg font-semibold text-stone-900">
          {brand}
        </a>
        <nav aria-label="Primary" className="ml-auto hidden lg:block">
          <ul className="flex items-center gap-7">
            {nav.map((item) => (
              <li key={item.label}>
                <a href={item.href} className="text-sm text-stone-700 transition-colors hover:text-emerald-800">
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <a href={ctaHref} className={`${buttonPrimary} ml-auto hidden py-2.5 lg:inline-flex`}>
          {ctaLabel}
        </a>
        <button
          type="button"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? 'Close menu' : 'Open menu'}
          onClick={() => setOpen((value) => !value)}
          className="ml-auto rounded-md p-2 text-stone-800 transition-colors hover:bg-stone-100 lg:hidden"
        >
          {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
        </button>
      </Container>
      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-stone-200 bg-white lg:hidden">
          <Container className="flex flex-col gap-1 py-4">
            {nav.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-md px-3 py-2.5 text-base text-stone-800 hover:bg-stone-100"
              >
                {item.label}
              </a>
            ))}
            <a href={ctaHref} onClick={() => setOpen(false)} className={`${buttonPrimary} mt-3`}>
              {ctaLabel}
            </a>
          </Container>
        </nav>
      )}
    </header>
  );
}

interface FooterColumn {
  title: string;
  links: NavItem[];
}

interface SiteFooterProps {
  brand: string;
  tagline: string;
  columns: FooterColumn[];
  legal: string;
}

export function SiteFooter({ brand, tagline, columns, legal }: SiteFooterProps) {
  return (
    <footer className="border-t border-stone-200 bg-stone-900 text-stone-200">
      <Container className="grid gap-12 py-16 md:grid-cols-[1.4fr_repeat(2,1fr)]">
        <div>
          <p className="font-display text-xl font-semibold text-white">{brand}</p>
          <p className="mt-4 max-w-xs text-sm leading-[1.5] text-stone-300">{tagline}</p>
        </div>
        {columns.map((column) => (
          <div key={column.title}>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-stone-400">{column.title}</h3>
            <ul className="mt-4 space-y-3">
              {column.links.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-stone-200 transition-colors hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </Container>
      <Container className="border-t border-stone-700 py-6">
        <p className="text-xs text-stone-400">{legal}</p>
      </Container>
    </footer>
  );
}

interface AnnouncementBarProps {
  message: string;
  linkLabel: string;
  linkHref: string;
}

export function AnnouncementBar({ message, linkLabel, linkHref }: AnnouncementBarProps) {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;

  return (
    <div role="region" aria-label="Announcement" className="bg-emerald-900 text-emerald-50">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-5 py-2.5 text-sm lg:px-10">
        <Megaphone className="hidden h-4 w-4 shrink-0 sm:block" aria-hidden="true" />
        <p className="flex-1 text-center sm:text-left">
          {message}{' '}
          <a href={linkHref} className="font-medium underline underline-offset-4 hover:text-white">
            {linkLabel}
          </a>
        </p>
        <button
          type="button"
          onClick={() => setDismissed(true)}
          aria-label="Dismiss announcement"
          className="rounded p-1 text-emerald-100 hover:bg-emerald-800 hover:text-white"
        >
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

const CONSENT_KEY = 'studio-cookie-consent';

export function CookieConsent({ message }: { message: string }) {
  const [choice, setChoice] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      setChoice(window.localStorage.getItem(CONSENT_KEY));
    } catch {
      setChoice(null);
    }
    setReady(true);
  }, []);

  function save(value: 'accepted' | 'declined') {
    try {
      window.localStorage.setItem(CONSENT_KEY, value);
    } catch {
      // Storage can be blocked; the banner still closes for this visit.
    }
    setChoice(value);
  }

  if (!ready || choice) return null;

  return (
    <div
      role="dialog"
      aria-label="Cookie preferences"
      className="fixed inset-x-4 bottom-4 z-50 mx-auto flex max-w-3xl flex-col gap-4 rounded-2xl border border-stone-200 bg-white p-5 shadow-xl sm:flex-row sm:items-center"
    >
      <div className="flex flex-1 gap-3">
        <Cookie className="mt-0.5 h-5 w-5 shrink-0 text-emerald-800" aria-hidden="true" />
        <p className="text-sm leading-[1.5] text-stone-700">{message}</p>
      </div>
      <div className="flex gap-2">
        <button type="button" onClick={() => save('declined')} className={`${buttonSecondary} py-2 text-sm`}>
          Decline
        </button>
        <button type="button" onClick={() => save('accepted')} className={`${buttonPrimary} py-2 text-sm`}>
          Accept
        </button>
      </div>
    </div>
  );
}

export function BackToTop({ label }: { label: string }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  if (!visible) return null;

  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      className="fixed bottom-6 right-6 z-40 inline-flex h-11 w-11 items-center justify-center rounded-full bg-stone-900 text-white shadow-lg transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-700 focus-visible:ring-offset-2"
    >
      <ArrowUp className="h-5 w-5" aria-hidden="true" />
      <span className="sr-only">{label}</span>
    </button>
  );
}

const navItems: NavItem[] = [
  { label: 'Services', href: '#services' },
  { label: 'Process', href: '#process' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact', href: '#contact' },
];

export const globalModules: ModuleDefinition[] = [
  {
    id: 'site-header',
    name: 'Site header',
    section: 'global',
    tier: 'Starter',
    purpose: 'Sticky top bar with brand, navigation, a call to action and a mobile menu.',
    defaults: {
      brand: 'Northwind Studio',
      nav: navItems,
      ctaLabel: 'Book a consultation',
      ctaHref: '#contact',
    },
    component: SiteHeader,
  },
  {
    id: 'site-footer',
    name: 'Site footer',
    section: 'global',
    tier: 'Starter',
    purpose: 'Multi-column footer with brand summary, link groups and legal line.',
    defaults: {
      brand: 'Northwind Studio',
      tagline: 'Thoughtful design and build work for businesses that want to be remembered.',
      columns: [
        {
          title: 'Company',
          links: [
            { label: 'About', href: '#about' },
            { label: 'Team', href: '#team' },
            { label: 'Careers', href: '#careers' },
          ],
        },
        {
          title: 'Support',
          links: [
            { label: 'Contact', href: '#contact' },
            { label: 'FAQ', href: '#faq' },
            { label: 'Privacy', href: '#privacy' },
          ],
        },
      ],
      legal: 'Copyright 2026 Northwind Studio. All rights reserved.',
    },
    component: SiteFooter,
  },
  {
    id: 'announcement-bar',
    name: 'Announcement bar',
    section: 'global',
    tier: 'Starter',
    purpose: 'Dismissible strip above the header for offers, launches or notices.',
    defaults: {
      message: 'Spring consultations are now open for new clients.',
      linkLabel: 'See availability',
      linkHref: '#contact',
    },
    component: AnnouncementBar,
  },
  {
    id: 'cookie-consent',
    name: 'Cookie consent',
    section: 'global',
    tier: 'Starter',
    purpose: 'Consent banner that remembers the visitor choice in their browser.',
    defaults: {
      message: 'We use cookies to keep the site working and to understand how it is used. You can change your mind at any time.',
    },
    component: CookieConsent,
  },
  {
    id: 'back-to-top',
    name: 'Back to top',
    section: 'global',
    tier: 'Starter',
    purpose: 'Floating button that appears after scrolling and returns the visitor to the top.',
    defaults: {
      label: 'Back to top',
    },
    component: BackToTop,
  },
];
