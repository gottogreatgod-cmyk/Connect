import { ChevronDown } from 'lucide-react';
import type { ModuleDefinition } from '@/modules/types';
import { Container, SectionHeading } from '@/modules/ui/primitives';

interface FaqItem {
  question: string;
  answer: string;
}

interface FAQAccordionProps {
  heading: string;
  intro: string;
  items: FaqItem[];
}

export function FAQAccordion({ heading, intro, items }: FAQAccordionProps) {
  return (
    <section id="faq" className="bg-white py-20 md:py-28">
      <Container className="max-w-3xl">
        <SectionHeading title={heading} intro={intro} />
        <div className="mt-12 divide-y divide-stone-200 border-y border-stone-200">
          {items.map((item) => (
            <details key={item.question} className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 rounded-md text-left text-base font-medium text-stone-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-700 [&::-webkit-details-marker]:hidden">
                {item.question}
                <ChevronDown
                  className="h-5 w-5 shrink-0 text-stone-600 transition-transform duration-200 group-open:rotate-180"
                  aria-hidden="true"
                />
              </summary>
              <p className="mt-4 pr-10 text-sm leading-[1.5] text-stone-700">{item.answer}</p>
            </details>
          ))}
        </div>
      </Container>
    </section>
  );
}

export const contentModules: ModuleDefinition[] = [
  {
    id: 'faq-accordion',
    name: 'FAQ accordion',
    section: 'content',
    tier: 'Starter',
    purpose: 'Expandable questions and answers built on native disclosure controls, so it works without scripts.',
    defaults: {
      heading: 'Questions we hear most',
      intro: 'Can not find what you need? Send us a message and we will answer it directly.',
      items: [
        {
          question: 'How long does a typical project take?',
          answer: 'Most single-site projects launch within four to six weeks, depending on how quickly content and feedback come in.',
        },
        {
          question: 'Will I be able to edit the site myself?',
          answer: 'Yes. We set up a simple editor and record a short walkthrough so your team can update text, photos and opening hours.',
        },
        {
          question: 'Do you help with hosting and domains?',
          answer: 'We handle setup, renewal reminders and security updates, and you keep full ownership of your domain at all times.',
        },
        {
          question: 'What happens after launch?',
          answer: 'You get 30 days of included support, then an optional monthly plan for changes, reports and ongoing improvements.',
        },
      ],
    },
    component: FAQAccordion,
  },
];
