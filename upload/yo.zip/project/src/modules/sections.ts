import type { SectionMeta } from '@/modules/types';

export const SECTIONS: SectionMeta[] = [
  { id: 'global', title: '01 Global system', description: 'Header, footer, bars, navigation and utility shells' },
  { id: 'hero', title: '02 Heroes and attention', description: 'Opening statements that set the page up' },
  { id: 'value', title: '03 Value and explanation', description: 'Benefits, process, pricing and explanation' },
  { id: 'proof', title: '04 Proof and trust', description: 'Reviews, results, credentials and reassurance' },
  { id: 'conversion', title: '05 Conversion', description: 'Calls to action, enquiries and sign-ups' },
  { id: 'commerce', title: '06 Commerce', description: 'Catalogue, basket and checkout surfaces' },
  { id: 'booking', title: '07 Booking and operations', description: 'Scheduling, reservations and service status' },
  { id: 'location', title: '08 Location and local SEO', description: 'Where you are, hours and service areas' },
  { id: 'content', title: '09 Content and SEO', description: 'Articles, FAQs, resources and structured data' },
  { id: 'people', title: '10 People and culture', description: 'Team, leadership and careers' },
  { id: 'hospitality', title: '11 Hospitality and food', description: 'Menus, rooms and experiences' },
  { id: 'property', title: '12 Real estate and property', description: 'Listings, valuations and property tools' },
  { id: 'automotive', title: '13 Automotive', description: 'Vehicle stock, service and finance' },
  { id: 'education', title: '14 Education and learning', description: 'Courses, lessons and enrolment' },
  { id: 'events', title: '15 Events and entertainment', description: 'Tickets, venues and programmes' },
  { id: 'b2b', title: '16 B2B and SaaS', description: 'Product, pricing, security and developer surfaces' },
  { id: 'regulated', title: '17 Finance, legal and regulated', description: 'Disclosures, consultations and secure intake' },
  { id: 'nonprofit', title: '18 Nonprofit and public sector', description: 'Mission, giving and public information' },
  { id: 'motion', title: '19 Motion and premium layers', description: 'Interaction, motion and 3D' },
  { id: 'forms', title: '20 Forms and feedback', description: 'Fields, validation, uploads and confirmations' },
];
