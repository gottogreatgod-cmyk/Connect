import { RotateCcw, X } from 'lucide-react';
import type { ModuleInstance } from '@/builder/composition';
import type { ModuleDefinition } from '@/modules/types';
import { FormField, buttonSecondary } from '@/modules/ui/primitives';

interface InstanceInspectorProps {
  instance: ModuleInstance | null;
  definition: ModuleDefinition | undefined;
  onUpdate: (key: string, value: string) => void;
  onReset: () => void;
  onClose: () => void;
}

function humanize(key: string): string {
  const spaced = key.replace(/([A-Z])/g, ' $1').trim();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

export function InstanceInspector({ instance, definition, onUpdate, onReset, onClose }: InstanceInspectorProps) {
  if (!instance || !definition) {
    return (
      <aside aria-label="Module editor" className="border-t border-stone-200 bg-white p-6 lg:sticky lg:top-0 lg:h-screen lg:border-l lg:border-t-0">
        <h2 className="font-display text-xl text-stone-900">Module editor</h2>
        <p className="mt-3 text-sm leading-[1.5] text-stone-600">
          Select a module on the page to edit its text, reorder it or remove it.
        </p>
      </aside>
    );
  }

  const editableKeys = Object.keys(definition.defaults).filter((key) => typeof definition.defaults[key] === 'string');
  const hasLists = Object.values(definition.defaults).some((value) => Array.isArray(value));

  return (
    <aside aria-label="Module editor" className="flex flex-col border-t border-stone-200 bg-white lg:sticky lg:top-0 lg:h-screen lg:border-l lg:border-t-0">
      <div className="flex items-start justify-between gap-3 border-b border-stone-200 p-5">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-800">Editing</p>
          <h2 className="mt-1 font-display text-xl text-stone-900">{definition.name}</h2>
          <p className="mt-1 text-xs text-stone-600">{definition.purpose}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close editor"
          className="rounded-md p-2 text-stone-700 transition-colors hover:bg-stone-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-700"
        >
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>

      <div className="min-h-0 flex-1 space-y-5 overflow-y-auto p-5">
        {editableKeys.length === 0 && <p className="text-sm text-stone-600">This module has no editable text.</p>}
        {editableKeys.map((key) => {
          const value = String(instance.props[key] ?? definition.defaults[key]);
          return (
            <FormField
              key={`${instance.uid}-${key}`}
              id={`inspector-${instance.uid}-${key}`}
              label={humanize(key)}
              multiline={definition.defaults[key].length > 60}
              value={value}
              onChange={(next) => onUpdate(key, next)}
            />
          );
        })}
        {hasLists && (
          <p className="rounded-lg bg-stone-50 p-3 text-xs leading-[1.5] text-stone-600">
            Lists in this module, such as items, plans or reviews, use sample content for now.
          </p>
        )}
      </div>

      <div className="flex gap-2 border-t border-stone-200 p-5">
        <button type="button" onClick={onReset} className={`${buttonSecondary} flex-1 py-2 text-sm`}>
          <RotateCcw className="h-4 w-4" aria-hidden="true" />
          Reset text
        </button>
      </div>
    </aside>
  );
}
