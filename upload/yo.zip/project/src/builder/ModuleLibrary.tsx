import { Plus, Search } from 'lucide-react';
import { useMemo, useState } from 'react';
import { MODULES } from '@/modules/registry';
import { SECTIONS } from '@/modules/sections';
import type { ModuleDefinition, SectionId, Tier } from '@/modules/types';

const TIER_STYLES: Record<Tier, string> = {
  Starter: 'bg-stone-200 text-stone-800',
  Growth: 'bg-emerald-100 text-emerald-900',
  Business: 'bg-amber-100 text-amber-900',
  Flagship: 'bg-sky-100 text-sky-900',
};

interface ModuleLibraryProps {
  onAdd: (moduleId: string) => void;
}

export function ModuleLibrary({ onAdd }: ModuleLibraryProps) {
  const [query, setQuery] = useState('');
  const [section, setSection] = useState<SectionId | 'all'>('all');

  const groups = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return SECTIONS.filter((meta) => section === 'all' || meta.id === section).map((meta) => ({
      ...meta,
      modules: MODULES.filter(
        (module) =>
          module.section === meta.id &&
          (needle === '' || module.name.toLowerCase().includes(needle) || module.purpose.toLowerCase().includes(needle)),
      ),
    }));
  }, [query, section]);

  const matchCount = groups.reduce((total, group) => total + group.modules.length, 0);

  return (
    <aside aria-label="Module library" className="flex flex-col border-b border-stone-200 bg-white lg:sticky lg:top-0 lg:h-screen lg:border-b-0 lg:border-r">
      <div className="space-y-4 border-b border-stone-200 p-5">
        <div>
          <h2 className="font-display text-xl text-stone-900">Module library</h2>
          <p className="mt-1 text-sm text-stone-600">{MODULES.length} ready-made modules. Select one to add it to your page.</p>
        </div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" aria-hidden="true" />
          <label htmlFor="module-search" className="sr-only">
            Search modules
          </label>
          <input
            id="module-search"
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search by name or purpose"
            className="w-full rounded-md border border-stone-300 bg-white py-2.5 pl-9 pr-3 text-sm text-stone-900 placeholder:text-stone-500 focus:border-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
          />
        </div>
        <div>
          <label htmlFor="module-section" className="text-xs font-medium text-stone-700">
            Section
          </label>
          <select
            id="module-section"
            value={section}
            onChange={(event) => setSection(event.target.value as SectionId | 'all')}
            className="mt-1.5 w-full rounded-md border border-stone-300 bg-white px-3 py-2.5 text-sm text-stone-900 focus:border-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
          >
            <option value="all">All sections</option>
            {SECTIONS.map((meta) => (
              <option key={meta.id} value={meta.id}>
                {meta.title}
              </option>
            ))}
          </select>
        </div>
        <p className="text-xs text-stone-600" aria-live="polite">
          {matchCount} {matchCount === 1 ? 'module' : 'modules'} shown
        </p>
      </div>

      <div className="p-5 lg:min-h-0 lg:flex-1 lg:overflow-y-auto">
        {matchCount === 0 && (
          <p className="rounded-xl border border-dashed border-stone-300 p-6 text-center text-sm text-stone-600">
            No modules match that search. Try a different word.
          </p>
        )}
        <div className="space-y-8">
          {groups
            .filter((group) => group.modules.length > 0)
            .map((group) => (
              <section key={group.id} aria-labelledby={`library-${group.id}`}>
                <h3 id={`library-${group.id}`} className="text-xs font-semibold uppercase tracking-[0.18em] text-stone-600">
                  {group.title}
                </h3>
                <ul className="mt-3 space-y-3">
                  {group.modules.map((module) => (
                    <li key={module.id}>
                      <ModuleCard module={module} onAdd={onAdd} />
                    </li>
                  ))}
                </ul>
              </section>
            ))}
        </div>
      </div>
    </aside>
  );
}

function ModuleCard({ module, onAdd }: { module: ModuleDefinition; onAdd: (moduleId: string) => void }) {
  return (
    <div className="group rounded-xl border border-stone-200 bg-stone-50 p-4 transition-colors hover:border-emerald-700 hover:bg-white">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-medium text-stone-900">{module.name}</p>
          <p className="mt-1 text-xs leading-[1.5] text-stone-600">{module.purpose}</p>
        </div>
        <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${TIER_STYLES[module.tier]}`}>
          {module.tier}
        </span>
      </div>
      <button
        type="button"
        onClick={() => onAdd(module.id)}
        aria-label={`Add ${module.name} to page`}
        className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-stone-900 px-3.5 py-1.5 text-xs font-medium text-white transition-colors hover:bg-emerald-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-700 focus-visible:ring-offset-2"
      >
        <Plus className="h-3.5 w-3.5" aria-hidden="true" />
        Add to page
      </button>
    </div>
  );
}
