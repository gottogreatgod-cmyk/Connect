import { getModule } from '@/modules/registry';

export interface ModuleInstance {
  uid: string;
  moduleId: string;
  props: Record<string, unknown>;
}

export type CompositionAction =
  | { type: 'add'; uid: string; moduleId: string }
  | { type: 'remove'; uid: string }
  | { type: 'move'; uid: string; direction: -1 | 1 }
  | { type: 'update'; uid: string; key: string; value: string }
  | { type: 'resetProps'; uid: string }
  | { type: 'replace'; modules: ModuleInstance[] }
  | { type: 'clear' };

export const STARTER_MODULE_IDS = [
  'announcement-bar',
  'site-header',
  'hero-editorial',
  'trust-bar',
  'benefit-grid',
  'how-it-works',
  'review-carousel',
  'contact-form',
  'faq-accordion',
  'site-footer',
];

export function createInstance(uid: string, moduleId: string): ModuleInstance | null {
  const definition = getModule(moduleId);
  if (!definition) return null;
  return { uid, moduleId, props: { ...definition.defaults } };
}

export function createStarterComposition(): ModuleInstance[] {
  return STARTER_MODULE_IDS.flatMap((moduleId, index) => {
    const instance = createInstance(`starter-${index}`, moduleId);
    return instance ? [instance] : [];
  });
}

export function compositionReducer(state: ModuleInstance[], action: CompositionAction): ModuleInstance[] {
  switch (action.type) {
    case 'add': {
      const instance = createInstance(action.uid, action.moduleId);
      return instance ? [...state, instance] : state;
    }
    case 'remove':
      return state.filter((instance) => instance.uid !== action.uid);
    case 'move': {
      const index = state.findIndex((instance) => instance.uid === action.uid);
      const target = index + action.direction;
      if (index < 0 || target < 0 || target >= state.length) return state;
      const next = [...state];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    }
    case 'update':
      return state.map((instance) =>
        instance.uid === action.uid
          ? { ...instance, props: { ...instance.props, [action.key]: action.value } }
          : instance,
      );
    case 'resetProps':
      return state.map((instance) => {
        if (instance.uid !== action.uid) return instance;
        const definition = getModule(instance.moduleId);
        return definition ? { ...instance, props: { ...definition.defaults } } : instance;
      });
    case 'replace':
      return action.modules;
    case 'clear':
      return [];
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function parseSavedModules(raw: unknown): ModuleInstance[] {
  if (!Array.isArray(raw)) return [];
  return raw.flatMap((entry): ModuleInstance[] => {
    if (!isRecord(entry) || typeof entry.uid !== 'string' || typeof entry.moduleId !== 'string') return [];
    const definition = getModule(entry.moduleId);
    if (!definition) return [];
    const props = isRecord(entry.props) ? entry.props : {};
    return [{ uid: entry.uid, moduleId: entry.moduleId, props: { ...definition.defaults, ...props } }];
  });
}
