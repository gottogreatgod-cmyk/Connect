import { Layers, Save, Trash2 } from 'lucide-react';
import { useEffect, useReducer, useState } from 'react';
import { InstanceInspector } from '@/builder/InstanceInspector';
import { ModuleLibrary } from '@/builder/ModuleLibrary';
import { PageCanvas } from '@/builder/PageCanvas';
import {
  compositionReducer,
  createStarterComposition,
  type CompositionAction,
} from '@/builder/composition';
import { loadLatestPage, savePage } from '@/builder/pageStorage';
import { getModule } from '@/modules/registry';
import { buttonPrimary, buttonSecondary } from '@/modules/ui/primitives';

type SaveStatus = 'idle' | 'saving' | 'saved' | 'error';

function createUid(moduleId: string): string {
  return `${moduleId}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function BuilderPage() {
  const [modules, dispatch] = useReducer(compositionReducer, []);
  const [selectedUid, setSelectedUid] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadFailed, setLoadFailed] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>('idle');

  useEffect(() => {
    let active = true;

    async function loadPageFromDatabase() {
      try {
        const page = await loadLatestPage();
        if (!active) return;
        setSavedId(page?.id ?? null);
        dispatch({ type: 'replace', modules: page ? page.modules : createStarterComposition() });
      } catch {
        if (!active) return;
        setLoadFailed(true);
        dispatch({ type: 'replace', modules: createStarterComposition() });
      } finally {
        if (active) setLoading(false);
      }
    }

    void loadPageFromDatabase();
    return () => {
      active = false;
    };
  }, []);

  function edit(action: CompositionAction) {
    dispatch(action);
    setSaveStatus('idle');
  }

  function handleAdd(moduleId: string) {
    const uid = createUid(moduleId);
    edit({ type: 'add', uid, moduleId });
    setSelectedUid(uid);
  }

  function handleRemove(uid: string) {
    edit({ type: 'remove', uid });
    setSelectedUid((current) => (current === uid ? null : current));
  }

  function handleUpdate(key: string, value: string) {
    if (selected) edit({ type: 'update', uid: selected.uid, key, value });
  }

  function handleResetSelected() {
    if (selected) edit({ type: 'resetProps', uid: selected.uid });
  }

  function handleClear() {
    const confirmed = window.confirm(
      'Remove every module from this page? Your last saved version stays until you save again.',
    );
    if (!confirmed) return;
    edit({ type: 'clear' });
    setSelectedUid(null);
  }

  async function handleSave() {
    setSaveStatus('saving');
    try {
      const page = await savePage(savedId, modules);
      setSavedId(page.id);
      setSaveStatus('saved');
    } catch {
      setSaveStatus('error');
    }
  }

  const selected = modules.find((instance) => instance.uid === selectedUid) ?? null;
  const selectedDefinition = selected ? getModule(selected.moduleId) : undefined;

  const statusText = {
    idle: savedId ? 'Save to keep your latest changes' : 'This page has not been saved yet',
    saving: 'Saving...',
    saved: 'All changes saved',
    error: 'Could not save your page. Please try again.',
  }[saveStatus];

  return (
    <div className="min-h-screen bg-stone-100">
      <header className="flex flex-wrap items-center gap-4 border-b border-stone-200 bg-white px-5 py-4 lg:px-8">
        <div className="flex items-center gap-3">
          <span className="rounded-xl bg-emerald-800 p-2 text-white">
            <Layers className="h-5 w-5" aria-hidden="true" />
          </span>
          <div>
            <h1 className="font-display text-xl leading-[1.2] text-stone-900">Module Studio</h1>
            <p className="text-xs text-stone-600">Build your page by selecting modules</p>
          </div>
        </div>
        <div className="flex w-full flex-wrap items-center gap-3 sm:ml-auto sm:w-auto">
          <p className="text-xs text-stone-600 sm:mr-2" role="status" aria-live="polite">
            {statusText}
          </p>
          <button
            type="button"
            onClick={handleClear}
            disabled={modules.length === 0}
            className={`${buttonSecondary} py-2 text-sm disabled:cursor-not-allowed disabled:opacity-50`}
          >
            <Trash2 className="h-4 w-4" aria-hidden="true" />
            Clear page
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={loading || saveStatus === 'saving'}
            className={`${buttonPrimary} py-2 text-sm disabled:cursor-not-allowed disabled:opacity-60`}
          >
            <Save className="h-4 w-4" aria-hidden="true" />
            Save page
          </button>
        </div>
      </header>

      {loadFailed && (
        <p role="alert" className="border-b border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-900 lg:px-8">
          We could not load your saved page, so the sample page is shown instead.
        </p>
      )}

      <div className="grid lg:grid-cols-[18rem_minmax(0,1fr)_20rem]">
        <ModuleLibrary onAdd={handleAdd} />
        <main id="main-content" className="min-w-0 p-5 lg:p-8">
          {loading ? (
            <p role="status" className="flex min-h-[60vh] items-center justify-center text-sm text-stone-600">
              Loading your page...
            </p>
          ) : (
            <PageCanvas
              modules={modules}
              selectedUid={selectedUid}
              onSelect={setSelectedUid}
              onMove={(uid, direction) => edit({ type: 'move', uid, direction })}
              onRemove={handleRemove}
            />
          )}
        </main>
        <InstanceInspector
          instance={selected}
          definition={selectedDefinition}
          onUpdate={handleUpdate}
          onReset={handleResetSelected}
          onClose={() => setSelectedUid(null)}
        />
      </div>
    </div>
  );
}
