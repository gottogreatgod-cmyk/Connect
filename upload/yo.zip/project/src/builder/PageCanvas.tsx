import { ArrowDown, ArrowUp, LayoutTemplate, Pencil, Trash2 } from 'lucide-react';
import type { ReactNode } from 'react';
import type { ModuleInstance } from '@/builder/composition';
import { getModule } from '@/modules/registry';

interface PageCanvasProps {
  modules: ModuleInstance[];
  selectedUid: string | null;
  onSelect: (uid: string) => void;
  onMove: (uid: string, direction: -1 | 1) => void;
  onRemove: (uid: string) => void;
}

export function PageCanvas({ modules, selectedUid, onSelect, onMove, onRemove }: PageCanvasProps) {
  if (modules.length === 0) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center rounded-3xl border border-dashed border-stone-300 bg-white p-10 text-center">
        <LayoutTemplate className="h-10 w-10 text-stone-500" aria-hidden="true" />
        <h2 className="mt-4 font-display text-2xl text-stone-900">Your page is empty</h2>
        <p className="mt-2 max-w-sm text-sm leading-[1.5] text-stone-600">
          Choose a module from the library to add it here. Modules stack from top to bottom in the order shown.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {modules.map((instance, index) => {
        const definition = getModule(instance.moduleId);
        if (!definition) return null;
        const Component = definition.component;
        const selected = instance.uid === selectedUid;

        return (
          <article
            key={instance.uid}
            aria-label={definition.name}
            onClick={() => onSelect(instance.uid)}
            className={`overflow-hidden rounded-2xl bg-white transition-shadow ${
              selected ? 'ring-2 ring-emerald-700 ring-offset-4 ring-offset-stone-100' : 'ring-1 ring-stone-200 hover:ring-stone-400'
            }`}
          >
            <header className="flex items-center justify-between gap-3 border-b border-stone-200 bg-stone-900 px-4 py-2 text-white">
              <p className="min-w-0 truncate text-xs font-medium">
                <span className="mr-2 text-stone-400">{String(index + 1).padStart(2, '0')}</span>
                {definition.name}
              </p>
              <div className="flex shrink-0 items-center gap-1">
                <IconButton label={`Move ${definition.name} up`} disabled={index === 0} onClick={() => onMove(instance.uid, -1)}>
                  <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />
                </IconButton>
                <IconButton
                  label={`Move ${definition.name} down`}
                  disabled={index === modules.length - 1}
                  onClick={() => onMove(instance.uid, 1)}
                >
                  <ArrowDown className="h-3.5 w-3.5" aria-hidden="true" />
                </IconButton>
                <IconButton label={`Edit ${definition.name}`} onClick={() => onSelect(instance.uid)}>
                  <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
                </IconButton>
                <IconButton label={`Remove ${definition.name}`} tone="danger" onClick={() => onRemove(instance.uid)}>
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                </IconButton>
              </div>
            </header>
            <Component {...instance.props} />
          </article>
        );
      })}
    </div>
  );
}

interface IconButtonProps {
  label: string;
  onClick: () => void;
  children: ReactNode;
  disabled?: boolean;
  tone?: 'default' | 'danger';
}

function IconButton({ label, onClick, children, disabled = false, tone = 'default' }: IconButtonProps) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={(event) => {
        event.stopPropagation();
        onClick();
      }}
      className={`rounded-md p-1.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 disabled:cursor-not-allowed disabled:opacity-40 ${
        tone === 'danger' ? 'text-rose-200 hover:bg-rose-900 hover:text-white' : 'text-stone-200 hover:bg-stone-700 hover:text-white'
      }`}
    >
      {children}
    </button>
  );
}
