import { parseSavedModules, type ModuleInstance } from '@/builder/composition';
import { supabase } from '@/lib/supabase';

export interface SavedPage {
  id: string;
  modules: ModuleInstance[];
}

const PAGE_NAME = 'Main page';

interface PageRow {
  id: string;
  modules: unknown;
}

function toSavedPage(row: PageRow): SavedPage {
  return { id: row.id, modules: parseSavedModules(row.modules) };
}

export async function loadLatestPage(): Promise<SavedPage | null> {
  const { data, error } = await supabase
    .from('page_compositions')
    .select('id, modules')
    .order('updated_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (!data) return null;
  return toSavedPage(data);
}

export async function savePage(existingId: string | null, modules: ModuleInstance[]): Promise<SavedPage> {
  const payload = { name: PAGE_NAME, modules, updated_at: new Date().toISOString() };

  const request = existingId
    ? supabase.from('page_compositions').update(payload).eq('id', existingId)
    : supabase.from('page_compositions').insert(payload);

  const { data, error } = await request.select('id, modules').single();
  if (error) throw new Error(error.message);
  return toSavedPage(data);
}
