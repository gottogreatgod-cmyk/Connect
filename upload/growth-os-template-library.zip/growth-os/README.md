# Growth OS — Template Library (proof of concept)

Sixteen complete, hand-designed business websites — 4 industries × 4 tiers — inside a
calm library shell with the tier list, Genome and inspector panels.

```
npm install
npm run dev        # http://localhost:5173
npm run build      # static build in dist/ (relative paths — host anywhere)
```

## What's where

```
index.html               library shell entry
site.html                template renderer entry (the shell frames this)
src/engine/
  registry.ts            ONE definition per template (the Template Definition File):
                         industry, tier, pages, modules, signature, palette, type, radius
  tiers.ts               tier ladder, prices, motion cap, comparison table
  genome.ts              7 switches, atmospheres, voices, contrast maths, quality gate
  resolve.ts             template DNA + genome → CSS tokens on <html>
src/kit/
  site-kit.tsx           behaviour only: routing, Reveal (motion-gated), forms + validation
  site-main.tsx          renderer: loads one site, listens to the shell over postMessage
  base.css, fonts.css    reset, motion contract, self-hosted fonts
src/sites/<industry>/    16 sites, each a .tsx + .css pair with its own design language
src/shell/               App, Sidebar (tier list + industries), Stage (device frames),
                         Panel (Genome · Tier · Build)
```

## The token contract (why the Genome works on hand-made designs)

Every site styles itself only through these variables, so the Genome can swap them
without breaking a layout:

`--bg --surface --ink --muted --line --primary --on-primary --accent`
`--display --body --mono` · `--r` (corner radius) · `--d` (density multiplier) · `--dur`
plus `html[data-motion="0..3"]` and `html[data-mode="light|dark"]`.

Motion is capped by tier (Starter 0 → Flagship 3); the Genome can only lower it.

## Adding a template

1. Add a `TemplateDef` to `src/engine/registry.ts` (both light and dark palettes).
2. Create `src/sites/<industry>/<name>.tsx` + `.css`, scoped under one root class.
   Use `useSite()` for `page`/`go`, `<Reveal>` for scroll motion, `useForm` + `rules` for flows.
3. Register it in `src/sites/index.ts`.
4. Run the QA: every page at 1280 and 390 wide, no console errors, no horizontal overflow,
   no placeholder text, primary action reachable within two clicks.

## Porting to Next.js

Sites and the shell are plain React. In a Next.js App Router project, render the shell at
`/` and each site at `/t/[slug]` (client components), keep the iframe + postMessage bridge,
and replace the `?t=` lookup with the route param.

All businesses, people, reviews and figures are fictional demo content and are labelled as such.
