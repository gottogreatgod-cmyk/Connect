import { defineConfig } from "vite"
import react from "@vitejs/plugin-react"
import { resolve } from "node:path"

// Two entries: the library shell (index.html) and the template renderer
// (site.html) that the shell frames. base "./" keeps every asset path
// relative so the build runs from any folder or static host.
export default defineConfig({
  base: "./",
  plugins: [react()],
  build: {
    rollupOptions: {
      input: { index: resolve(__dirname, "index.html"), site: resolve(__dirname, "site.html") },
    },
    assetsInlineLimit: 0,
    chunkSizeWarningLimit: 900,
  },
})
