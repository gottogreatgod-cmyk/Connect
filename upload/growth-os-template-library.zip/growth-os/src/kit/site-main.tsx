import { StrictMode, Suspense, useEffect, useMemo, useState } from "react"
import { createRoot } from "react-dom/client"
import "./base.css"
import { decodeGenome, isGenome, type Genome } from "../engine/genome"
import { findTemplate, TEMPLATES } from "../engine/registry"
import { applyTokens, resolve } from "../engine/resolve"
import { SITES } from "../sites"
import { SiteContext } from "./site-kit"

/**
 * The renderer. Loads ONE template full-page and listens to the library
 * shell (when framed) for genome changes and page jumps. Opened on its
 * own, it is simply that business's website.
 */

const qs = new URLSearchParams(location.search)
const embedded = window.parent !== window
const tpl = findTemplate(qs.get("t")) ?? TEMPLATES[0]
const Site = SITES[tpl.slug]
const pageIds = tpl.pages.map((p) => p.id)
const initialPage = (() => {
  const h = location.hash.slice(1)
  const p = qs.get("p")
  if (h && pageIds.includes(h)) return h
  if (p && pageIds.includes(p)) return p
  return "home"
})()

document.title = `${tpl.name} — ${tpl.kind}`

const post = (msg: Record<string, unknown>) => {
  if (embedded) window.parent.postMessage({ source: "gos-site", slug: tpl.slug, ...msg }, "*")
}

function Renderer() {
  const [genome, setGenome] = useState<Genome>(() => decodeGenome(qs.get("g")))
  const [page, setPage] = useState(initialPage)
  const tokens = useMemo(() => resolve(tpl, genome), [genome])

  useEffect(() => {
    applyTokens(document.documentElement, tokens)
  }, [tokens])

  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      const d = e.data as { source?: string; type?: string; genome?: unknown; page?: string }
      if (!d || d.source !== "gos-shell") return
      if (d.type === "genome" && isGenome(d.genome)) setGenome(d.genome)
      if (d.type === "go" && d.page && pageIds.includes(d.page)) go(d.page)
    }
    window.addEventListener("message", onMsg)
    post({ type: "ready", page })
    return () => window.removeEventListener("message", onMsg)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (embedded) return
    const onHash = () => {
      const h = location.hash.slice(1)
      if (pageIds.includes(h)) setPage(h)
      else if (!h) setPage("home")
    }
    window.addEventListener("hashchange", onHash)
    return () => window.removeEventListener("hashchange", onHash)
  }, [])

  function go(next: string) {
    if (!pageIds.includes(next)) return
    setPage(next)
    window.scrollTo({ top: 0, behavior: "auto" })
    post({ type: "page", page: next })
    if (!embedded) history.replaceState(null, "", next === "home" ? location.pathname + location.search : `#${next}`)
  }

  const ctx = useMemo(() => ({ page, go, motion: tokens.motion, tier: tpl.tier, embedded }), [page, tokens.motion])

  return (
    <SiteContext.Provider value={ctx}>
      <Suspense fallback={<div className="site-loading">Loading {tpl.name}</div>}>
        <Site />
      </Suspense>
    </SiteContext.Provider>
  )
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Renderer />
  </StrictMode>,
)
